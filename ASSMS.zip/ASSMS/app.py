"""
Aylota Secondary School Management System (ASSMS)
Complete single-file Flask Application
Run: python app.py
"""

from flask import Flask, render_template, redirect, url_for, session, Response, stream_with_context, request, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date
import hashlib
import os
import json
import threading
import time
import heapq

# ═════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═════════════════════════════════════════════════════════════════════════════

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'assms-dev-secret-key-change-in-production'
    # Use SQLite by default for easy testing (change to MySQL for production)
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///assms.db'
    # For MySQL: 'mysql+pymysql://root:@localhost/assms_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_PERMANENT = False


# ═════════════════════════════════════════════════════════════════════════════
# DATABASE MODELS
# ═════════════════════════════════════════════════════════════════════════════

db = SQLAlchemy()


class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='Student')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Student(db.Model):
    __tablename__ = 'students'
    student_id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    gender = db.Column(db.String(10))
    grade = db.Column(db.String(10))
    section = db.Column(db.String(10))
    phone = db.Column(db.String(20))
    address = db.Column(db.String(200))
    dob = db.Column(db.Date)
    parent = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Teacher(db.Model):
    __tablename__ = 'teachers'
    teacher_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    department = db.Column(db.String(50))
    phone = db.Column(db.String(20))
    email = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Subject(db.Model):
    __tablename__ = 'subjects'
    subject_id = db.Column(db.Integer, primary_key=True)
    subject_name = db.Column(db.String(50), nullable=False)
    teacher_id = db.Column(db.Integer, db.ForeignKey('teachers.teacher_id'))
    teacher = db.relationship('Teacher', backref='subjects')


class Attendance(db.Model):
    __tablename__ = 'attendance'
    attendance_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.student_id'))
    student = db.relationship('Student', backref='attendances')
    date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Exam(db.Model):
    __tablename__ = 'exams'
    exam_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.student_id'))
    student = db.relationship('Student', backref='exams')
    subject_id = db.Column(db.Integer, db.ForeignKey('subjects.subject_id'))
    subject = db.relationship('Subject', backref='exams')
    score = db.Column(db.Float)
    term = db.Column(db.String(20), default='Term 1')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Fee(db.Model):
    __tablename__ = 'fees'
    fee_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.student_id'))
    student = db.relationship('Student', backref='fees')
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), nullable=False)
    date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Book(db.Model):
    __tablename__ = 'books'
    book_id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    author = db.Column(db.String(100))
    quantity = db.Column(db.Integer, default=0)
    isbn = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Borrow(db.Model):
    __tablename__ = 'borrows'
    borrow_id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.Integer, db.ForeignKey('books.book_id'))
    book = db.relationship('Book', backref='borrows')
    student_id = db.Column(db.Integer, db.ForeignKey('students.student_id'))
    student = db.relationship('Student', backref='borrows')
    borrow_date = db.Column(db.Date, nullable=False)
    return_date = db.Column(db.Date)
    status = db.Column(db.String(20), default='borrowed')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ═════════════════════════════════════════════════════════════════════════════
# SCHEDULER (In-memory event scheduling)
# ═════════════════════════════════════════════════════════════════════════════

_event_heap = []
_event_lock = threading.Lock()
_event_counter = 0
_event_queue = []  # For SSE streaming
_queue_lock = threading.Lock()


def schedule_at(run_at, job_id, payload):
    """Schedule an event to run at a specific datetime"""
    global _event_counter
    with _event_lock:
        heapq.heappush(_event_heap, (run_at.timestamp(), _event_counter, job_id, payload))
        _event_counter += 1


def schedule_daily(hour, minute, job_id, payload):
    """Schedule a daily event"""
    now = datetime.now()
    run_at = datetime(now.year, now.month, now.day, hour, minute)
    if run_at < now:
        from datetime import timedelta
        run_at = run_at + timedelta(days=1)
    schedule_at(run_at, job_id, payload)


def pop_event():
    """Pop the next ready event"""
    with _event_lock:
        if not _event_heap:
            return None
        next_event = _event_heap[0]
        if next_event[0] <= time.time():
            heapq.heappop(_event_heap)
            return {
                'job_id': next_event[2],
                'payload': next_event[3],
                'triggered_at': datetime.now().isoformat()
            }
        return None


def _event_processor():
    """Background thread that processes scheduled events"""
    while True:
        event = pop_event()
        if event:
            with _queue_lock:
                _event_queue.append(event)
        time.sleep(1)


# Start the scheduler background thread
_processor_thread = threading.Thread(target=_event_processor, daemon=True)
_processor_thread.start()


# ═════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═════════════════════════════════════════════════════════════════════════════

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def calculate_gpa(avg_score):
    if avg_score >= 90:
        return 'A (4.0)'
    if avg_score >= 80:
        return 'B (3.0)'
    if avg_score >= 70:
        return 'C (2.0)'
    if avg_score >= 60:
        return 'D (1.0)'
    return 'F (0.0)'


def login_required(f):
    """Decorator to protect routes"""
    from functools import wraps

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


# ═════════════════════════════════════════════════════════════════════════════
# FLASK APP FACTORY
# ═════════════════════════════════════════════════════════════════════════════

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)

    # ─────────────────────────────────────────────────────────────────────────
    # ALARM / SSE ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/alarms/schedule', methods=['POST'])
    def alarms_schedule():
        data = request.json or {}
        when = data.get('when')
        job_id = data.get('job_id')
        payload = data.get('payload', {})
        if not when or not job_id:
            return jsonify({'error': 'when and job_id required'}), 400
        try:
            run_at = datetime.fromisoformat(when)
        except Exception:
            return jsonify({'error': 'invalid datetime format'}), 400
        schedule_at(run_at, job_id, payload)
        return jsonify({'status': 'scheduled', 'job_id': job_id})

    @app.route('/alarms/stream')
    def alarms_stream():
        def event_stream():
            while True:
                ev = None
                with _queue_lock:
                    if _event_queue:
                        ev = _event_queue.pop(0)
                if ev:
                    try:
                        payload = json.dumps(ev)
                    except Exception:
                        payload = str(ev)
                    yield f"data: {payload}\n\n"
                else:
                    time.sleep(0.5)

        return Response(stream_with_context(event_stream()), mimetype='text/event-stream')

    # ─────────────────────────────────────────────────────────────────────────
    # AUTH ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/auth/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            role = request.form.get('login_role', 'admin')

            user = User.query.filter_by(username=username).first()
            if user and user.password == hash_password(password) and user.role.lower() == role.lower():
                session['user_id'] = user.id
                session['username'] = user.username
                session['role'] = user.role
                flash('Login successful!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid credentials or role mismatch', 'error')

        return render_template_string(LOGIN_TEMPLATE)

    @app.route('/auth/register', methods=['POST'])
    def register():
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role', 'Student')

        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return redirect(url_for('login'))

        user = User(
            username=username,
            password=hash_password(password),
            role=role
        )
        db.session.add(user)
        db.session.commit()
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))

    @app.route('/auth/logout')
    def logout():
        session.clear()
        flash('Logged out successfully', 'info')
        return redirect(url_for('login'))

    # ─────────────────────────────────────────────────────────────────────────
    # MAIN ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/')
    def index():
        if session.get('user_id'):
            return redirect(url_for('dashboard'))
        return redirect(url_for('login'))

    @app.route('/dashboard')
    @login_required
    def dashboard():
        return render_template_string(DASHBOARD_TEMPLATE)

    # ─────────────────────────────────────────────────────────────────────────
    # STUDENT ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/api/students', methods=['GET'])
    @login_required
    def get_students():
        students = Student.query.all()
        return jsonify([{
            'student_id': s.student_id,
            'first_name': s.first_name,
            'last_name': s.last_name,
            'gender': s.gender,
            'grade': s.grade,
            'section': s.section,
            'phone': s.phone,
            'address': s.address,
            'dob': s.dob.isoformat() if s.dob else None,
            'parent': s.parent
        } for s in students])

    @app.route('/api/students', methods=['POST'])
    @login_required
    def create_student():
        data = request.json
        try:
            dob = datetime.strptime(data.get('dob'), '%Y-%m-%d').date() if data.get('dob') else None
        except Exception:
            dob = None
        student = Student(
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            gender=data.get('gender'),
            grade=data.get('grade'),
            section=data.get('section'),
            phone=data.get('phone'),
            address=data.get('address'),
            dob=dob,
            parent=data.get('parent')
        )
        db.session.add(student)
        db.session.commit()
        return jsonify({'success': True, 'student_id': student.student_id})

    @app.route('/api/students/<int:student_id>', methods=['PUT'])
    @login_required
    def update_student(student_id):
        student = Student.query.get_or_404(student_id)
        data = request.json
        student.first_name = data.get('first_name', student.first_name)
        student.last_name = data.get('last_name', student.last_name)
        student.gender = data.get('gender', student.gender)
        student.grade = data.get('grade', student.grade)
        student.section = data.get('section', student.section)
        student.phone = data.get('phone', student.phone)
        student.address = data.get('address', student.address)
        student.parent = data.get('parent', student.parent)
        if data.get('dob'):
            try:
                student.dob = datetime.strptime(data.get('dob'), '%Y-%m-%d').date()
            except Exception:
                pass
        db.session.commit()
        return jsonify({'success': True})

    @app.route('/api/students/<int:student_id>', methods=['DELETE'])
    @login_required
    def delete_student(student_id):
        student = Student.query.get_or_404(student_id)
        db.session.delete(student)
        db.session.commit()
        return jsonify({'success': True})

    @app.route('/api/students/search')
    @login_required
    def search_students():
        query = request.args.get('q', '')
        grade = request.args.get('grade', '')
        students = Student.query
        if query:
            students = students.filter(
                (Student.first_name.contains(query)) |
                (Student.last_name.contains(query))
            )
        if grade:
            students = students.filter_by(grade=grade)
        students = students.all()
        return jsonify([{
            'student_id': s.student_id,
            'first_name': s.first_name,
            'last_name': s.last_name,
            'gender': s.gender,
            'grade': s.grade,
            'section': s.section,
            'phone': s.phone,
            'address': s.address,
            'dob': s.dob.isoformat() if s.dob else None,
            'parent': s.parent
        } for s in students])

    @app.route('/api/students/<int:student_id>/profile')
    @login_required
    def student_profile(student_id):
        s = Student.query.get_or_404(student_id)
        attendance = Attendance.query.filter_by(student_id=student_id).all()
        exams = Exam.query.filter_by(student_id=student_id).all()
        fees = Fee.query.filter_by(student_id=student_id).all()
        avg_score = sum(e.score for e in exams) / len(exams) if exams else 0
        return jsonify({
            'student': {
                'student_id': s.student_id,
                'first_name': s.first_name,
                'last_name': s.last_name,
                'gender': s.gender,
                'grade': s.grade,
                'section': s.section,
                'phone': s.phone,
                'address': s.address,
                'dob': s.dob.isoformat() if s.dob else None,
                'parent': s.parent
            },
            'attendance': {
                'present': sum(1 for a in attendance if a.status == 'present'),
                'absent': sum(1 for a in attendance if a.status == 'absent'),
                'late': sum(1 for a in attendance if a.status == 'late'),
                'total': len(attendance)
            },
            'exams': [{
                'subject': e.subject.subject_name if e.subject else 'Unknown',
                'score': e.score,
                'term': e.term
            } for e in exams],
            'gpa': calculate_gpa(avg_score),
            'average_score': round(avg_score, 2),
            'fees': [{
                'amount': f.amount,
                'status': f.status,
                'date': f.date.isoformat()
            } for f in fees]
        })

    # ─────────────────────────────────────────────────────────────────────────
    # TEACHER ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/api/teachers', methods=['GET'])
    @login_required
    def get_teachers():
        teachers = Teacher.query.all()
        return jsonify([{
            'teacher_id': t.teacher_id,
            'name': t.name,
            'department': t.department,
            'phone': t.phone,
            'email': t.email
        } for t in teachers])

    @app.route('/api/teachers', methods=['POST'])
    @login_required
    def create_teacher():
        data = request.json
        teacher = Teacher(
            name=data.get('name'),
            department=data.get('department'),
            phone=data.get('phone'),
            email=data.get('email')
        )
        db.session.add(teacher)
        db.session.commit()
        return jsonify({'success': True, 'teacher_id': teacher.teacher_id})

    @app.route('/api/teachers/<int:teacher_id>', methods=['PUT'])
    @login_required
    def update_teacher(teacher_id):
        teacher = Teacher.query.get_or_404(teacher_id)
        data = request.json
        teacher.name = data.get('name', teacher.name)
        teacher.department = data.get('department', teacher.department)
        teacher.phone = data.get('phone', teacher.phone)
        teacher.email = data.get('email', teacher.email)
        db.session.commit()
        return jsonify({'success': True})

    @app.route('/api/teachers/<int:teacher_id>', methods=['DELETE'])
    @login_required
    def delete_teacher(teacher_id):
        teacher = Teacher.query.get_or_404(teacher_id)
        db.session.delete(teacher)
        db.session.commit()
        return jsonify({'success': True})

    # ─────────────────────────────────────────────────────────────────────────
    # ATTENDANCE ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/api/attendance', methods=['GET'])
    @login_required
    def get_attendance():
        attendance = Attendance.query.all()
        return jsonify([{
            'attendance_id': a.attendance_id,
            'student_id': a.student_id,
            'student_name': f"{a.student.first_name} {a.student.last_name}" if a.student else 'Unknown',
            'date': a.date.isoformat(),
            'status': a.status
        } for a in attendance])

    @app.route('/api/attendance', methods=['POST'])
    @login_required
    def create_attendance():
        data = request.json
        attendance = Attendance(
            student_id=data.get('student_id'),
            date=datetime.strptime(data.get('date'), '%Y-%m-%d').date(),
            status=data.get('status')
        )
        db.session.add(attendance)
        db.session.commit()
        return jsonify({'success': True, 'attendance_id': attendance.attendance_id})

    @app.route('/api/attendance/student/<int:student_id>')
    @login_required
    def get_student_attendance(student_id):
        attendance = Attendance.query.filter_by(student_id=student_id).all()
        return jsonify([{
            'date': a.date.isoformat(),
            'status': a.status
        } for a in attendance])

    # ─────────────────────────────────────────────────────────────────────────
    # EXAM ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/api/exams', methods=['GET'])
    @login_required
    def get_exams():
        exams = Exam.query.all()
        return jsonify([{
            'exam_id': e.exam_id,
            'student_id': e.student_id,
            'student_name': f"{e.student.first_name} {e.student.last_name}" if e.student else 'Unknown',
            'subject_id': e.subject_id,
            'subject_name': e.subject.subject_name if e.subject else 'Unknown',
            'score': e.score,
            'term': e.term
        } for e in exams])

    @app.route('/api/exams', methods=['POST'])
    @login_required
    def create_exam():
        data = request.json
        exam = Exam(
            student_id=data.get('student_id'),
            subject_id=data.get('subject_id'),
            score=data.get('score'),
            term=data.get('term', 'Term 1')
        )
        db.session.add(exam)
        db.session.commit()
        return jsonify({'success': True, 'exam_id': exam.exam_id})

    @app.route('/api/subjects', methods=['GET'])
    @login_required
    def get_subjects():
        subjects = Subject.query.all()
        return jsonify([{
            'subject_id': s.subject_id,
            'subject_name': s.subject_name
        } for s in subjects])

    # ─────────────────────────────────────────────────────────────────────────
    # FINANCE ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/api/fees', methods=['GET'])
    @login_required
    def get_fees():
        fees = Fee.query.all()
        return jsonify([{
            'fee_id': f.fee_id,
            'student_id': f.student_id,
            'student_name': f"{f.student.first_name} {f.student.last_name}" if f.student else 'Unknown',
            'amount': f.amount,
            'status': f.status,
            'date': f.date.isoformat()
        } for f in fees])

    @app.route('/api/fees', methods=['POST'])
    @login_required
    def create_fee():
        data = request.json
        fee = Fee(
            student_id=data.get('student_id'),
            amount=data.get('amount'),
            status=data.get('status'),
            date=datetime.strptime(data.get('date'), '%Y-%m-%d').date()
        )
        db.session.add(fee)
        db.session.commit()
        return jsonify({'success': True, 'fee_id': fee.fee_id})

    # ─────────────────────────────────────────────────────────────────────────
    # LIBRARY ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/api/library/books', methods=['GET'])
    @login_required
    def get_books():
        books = Book.query.all()
        return jsonify([{
            'book_id': b.book_id,
            'title': b.title,
            'author': b.author,
            'quantity': b.quantity,
            'isbn': b.isbn
        } for b in books])

    @app.route('/api/library/books', methods=['POST'])
    @login_required
    def create_book():
        data = request.json
        book = Book(
            title=data.get('title'),
            author=data.get('author'),
            quantity=data.get('quantity', 0),
            isbn=data.get('isbn')
        )
        db.session.add(book)
        db.session.commit()
        return jsonify({'success': True, 'book_id': book.book_id})

    @app.route('/api/library/books/<int:book_id>', methods=['DELETE'])
    @login_required
    def delete_book(book_id):
        book = Book.query.get_or_404(book_id)
        db.session.delete(book)
        db.session.commit()
        return jsonify({'success': True})

    @app.route('/api/library/borrow', methods=['POST'])
    @login_required
    def borrow_book():
        data = request.json
        borrow = Borrow(
            book_id=data.get('book_id'),
            student_id=data.get('student_id'),
            borrow_date=datetime.strptime(data.get('borrow_date'), '%Y-%m-%d').date(),
            return_date=datetime.strptime(data.get('return_date'), '%Y-%m-%d').date() if data.get('return_date') else None,
            status='returned' if data.get('return_date') else 'borrowed'
        )
        db.session.add(borrow)
        db.session.commit()
        return jsonify({'success': True, 'borrow_id': borrow.borrow_id})

    @app.route('/api/library/borrows', methods=['GET'])
    @login_required
    def get_borrows():
        borrows = Borrow.query.all()
        return jsonify([{
            'borrow_id': b.borrow_id,
            'book_id': b.book_id,
            'book_title': b.book.title if b.book else 'Unknown',
            'student_id': b.student_id,
            'student_name': f"{b.student.first_name} {b.student.last_name}" if b.student else 'Unknown',
            'borrow_date': b.borrow_date.isoformat(),
            'return_date': b.return_date.isoformat() if b.return_date else None,
            'status': b.status
        } for b in borrows])

    # ─────────────────────────────────────────────────────────────────────────
    # USER ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/api/users', methods=['GET'])
    @login_required
    def get_users():
        users = User.query.all()
        return jsonify([{
            'id': u.id,
            'username': u.username,
            'role': u.role
        } for u in users])

    @app.route('/api/users', methods=['POST'])
    @login_required
    def create_user():
        data = request.json
        if User.query.filter_by(username=data.get('username')).first():
            return jsonify({'success': False, 'message': 'Username exists'}), 400
        user = User(
            username=data.get('username'),
            password=hash_password(data.get('password')),
            role=data.get('role', 'Student')
        )
        db.session.add(user)
        db.session.commit()
        return jsonify({'success': True, 'id': user.id})

    @app.route('/api/users/<int:user_id>', methods=['DELETE'])
    @login_required
    def delete_user(user_id):
        user = User.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
        return jsonify({'success': True})

    # ─────────────────────────────────────────────────────────────────────────
    # REPORT ROUTES
    # ─────────────────────────────────────────────────────────────────────────

    @app.route('/api/reports/students')
    @login_required
    def report_students():
        students = Student.query.all()
        data = []
        for s in students:
            exams = Exam.query.filter_by(student_id=s.student_id).all()
            avg_score = sum(e.score for e in exams) / len(exams) if exams else 0
            data.append({
                'id': s.student_id,
                'name': f"{s.first_name} {s.last_name}",
                'grade': s.grade,
                'gpa': calculate_gpa(avg_score)
            })
        return jsonify(data)

    @app.route('/api/reports/attendance')
    @login_required
    def report_attendance():
        students = Student.query.all()
        data = []
        for s in students:
            att = Attendance.query.filter_by(student_id=s.student_id).all()
            data.append({
                'student': f"{s.first_name} {s.last_name}",
                'present': sum(1 for a in att if a.status == 'present'),
                'absent': sum(1 for a in att if a.status == 'absent'),
                'late': sum(1 for a in att if a.status == 'late'),
                'total': len(att)
            })
        return jsonify(data)

    @app.route('/api/reports/exams')
    @login_required
    def report_exams():
        students = Student.query.all()
        data = []
        for s in students:
            exams = Exam.query.filter_by(student_id=s.student_id).all()
            avg_score = sum(e.score for e in exams) / len(exams) if exams else 0
            data.append({
                'student': f"{s.first_name} {s.last_name}",
                'average': round(avg_score, 2),
                'gpa': calculate_gpa(avg_score),
                'exams_taken': len(exams)
            })
        return jsonify(data)

    @app.route('/api/reports/finance')
    @login_required
    def report_finance():
        students = Student.query.all()
        data = []
        for s in students:
            fees = Fee.query.filter_by(student_id=s.student_id).all()
            total = sum(f.amount for f in fees)
            paid = sum(f.amount for f in fees if f.status == 'paid')
            data.append({
                'student': f"{s.first_name} {s.last_name}",
                'total': total,
                'paid': paid,
                'balance': total - paid,
                'status': fees[0].status if fees else 'N/A'
            })
        return jsonify(data)

    return app


# ═════════════════════════════════════════════════════════════════════════════
# HTML TEMPLATES (embedded for single-file convenience)
# ═════════════════════════════════════════════════════════════════════════════

LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ASSMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #e8edf5 0%, #d5dce8 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; font-family: 'Segoe UI', sans-serif; }
        .login-card { background: white; border-radius: 20px; padding: 40px; max-width: 440px; width: 100%; box-shadow: 0 20px 60px rgba(0,0,0,0.1); }
        .brand { text-align: center; margin-bottom: 30px; }
        .brand i { font-size: 3rem; color: #0d6efd; background: #e3f0ff; padding: 16px; border-radius: 50%; }
        .brand h3 { font-weight: 700; margin-top: 10px; color: #1e2a3a; }
        .brand p { color: #6c7a8a; margin: 0; font-size: 0.95rem; }
        .role-selector { display: flex; gap: 8px; justify-content: center; margin-bottom: 20px; flex-wrap: wrap; }
        .role-btn { border-radius: 30px; padding: 6px 18px; border: 2px solid #dce1e8; background: transparent; cursor: pointer; transition: 0.2s; font-size: 0.85rem; font-weight: 500; }
        .role-btn.active { border-color: #0d6efd; background: #0d6efd; color: white; }
        .role-btn:hover:not(.active) { border-color: #b0b8c4; }
        .btn-primary { border-radius: 10px; padding: 12px; font-weight: 600; width: 100%; }
        .form-control, .form-select { border-radius: 10px; padding: 12px; }
        .divider { display: flex; align-items: center; margin: 20px 0; color: #adb5bd; font-size: 0.85rem; }
        .divider::before, .divider::after { content: ''; flex: 1; border-bottom: 1px solid #e9ecef; }
        .divider::before { margin-right: 16px; }
        .divider::after { margin-left: 16px; }
        .flashes { list-style: none; padding: 0; }
        .flashes li { padding: 10px 16px; border-radius: 8px; margin-bottom: 8px; font-size: 0.9rem; }
        .flashes .success { background: #d4edda; color: #155724; }
        .flashes .error { background: #f8d7da; color: #721c24; }
        .flashes .info { background: #d1ecf1; color: #0c5460; }
        .demo-badges { text-align: center; margin-top: 16px; font-size: 0.85rem; color: #6c7a8a; }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="brand">
            <i class="fas fa-school"></i>
            <h3>ASSMS</h3>
            <p>Aylota Secondary School<br>Management System</p>
        </div>

        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                <ul class="flashes">
                {% for category, msg in messages %}
                    <li class="{{ category }}">{{ msg }}</li>
                {% endfor %}
                </ul>
            {% endif %}
        {% endwith %}

        <form method="post" action="{{ url_for('login') }}">
            <input type="hidden" name="login_role" id="loginRoleInput" value="admin">
            <div class="role-selector">
                <button type="button" class="role-btn active" data-role="admin">Admin</button>
                <button type="button" class="role-btn" data-role="teacher">Teacher</button>
                <button type="button" class="role-btn" data-role="student">Student</button>
                <button type="button" class="role-btn" data-role="parent">Parent</button>
            </div>
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" class="form-control" name="username" placeholder="Enter username" required autofocus>
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" class="form-control" name="password" placeholder="Enter password" required>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-sign-in-alt me-2"></i>Sign In</button>
        </form>

        <div class="divider">or</div>

        <form method="post" action="{{ url_for('register') }}">
            <div class="mb-3">
                <label class="form-label">New Username</label>
                <input type="text" class="form-control" name="username" placeholder="Choose username" required>
            </div>
            <div class="mb-3">
                <label class="form-label">New Password</label>
                <input type="password" class="form-control" name="password" placeholder="Choose password" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Role</label>
                <select class="form-select" name="role">
                    <option value="Admin">Admin</option>
                    <option value="Teacher">Teacher</option>
                    <option value="Student">Student</option>
                    <option value="Parent">Parent</option>
                </select>
            </div>
            <button type="submit" class="btn btn-outline-primary" style="border-radius:10px;padding:12px;font-weight:600;width:100%;">
                <i class="fas fa-user-plus me-2"></i>Create Account
            </button>
        </form>

        <div class="demo-badges">
            Demo: <span class="badge bg-light text-dark">admin / admin123</span>
        </div>
    </div>

    <script>
        document.querySelectorAll('.role-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.role-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                document.getElementById('loginRoleInput').value = this.dataset.role;
            });
        });
    </script>
</body>
</html>
"""


DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - ASSMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary:#0d6efd; --sidebar-width:260px; --header-height:60px; --bg-light:#f4f6f9; --bg-white:#fff; --text-dark:#1e2a3a; --text-muted:#6c7a8a; --border-color:#eef2f6; --shadow:0 2px 8px rgba(0,0,0,0.04); }
        [data-theme="dark"] { --bg-light:#1a1e2b; --bg-white:#252b3d; --text-dark:#e8edf5; --text-muted:#a0aec0; --border-color:#3a4055; }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Segoe UI',Tahoma,sans-serif; background:var(--bg-light); display:flex; min-height:100vh; color:var(--text-dark); transition:0.3s; }
        .sidebar { width:var(--sidebar-width); background:#1e2a3a; color:#fff; position:fixed; top:0; left:0; height:100vh; overflow-y:auto; z-index:1050; transition:transform 0.3s; padding-top:10px; }
        [data-theme="dark"] .sidebar { background:#141a26; }
        .sidebar .brand { font-size:1.3rem; font-weight:700; padding:18px 20px; border-bottom:1px solid rgba(255,255,255,0.08); display:flex; align-items:center; gap:10px; }
        .sidebar .brand i { color:#4fc3f7; }
        .sidebar .nav-link { color:rgba(255,255,255,0.7); padding:12px 20px; border-radius:6px; margin:2px 10px; transition:0.25s; display:flex; align-items:center; gap:12px; cursor:pointer; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background:rgba(255,255,255,0.08); color:#fff; }
        .sidebar .nav-link i { width:22px; text-align:center; }
        .sidebar .nav-section { font-size:0.7rem; text-transform:uppercase; letter-spacing:0.08em; color:rgba(255,255,255,0.3); padding:16px 20px 6px; }
        .main-content { margin-left:var(--sidebar-width); flex:1; min-height:100vh; display:flex; flex-direction:column; }
        .top-nav { height:var(--header-height); background:var(--bg-white); border-bottom:1px solid var(--border-color); display:flex; align-items:center; justify-content:space-between; padding:0 28px; position:sticky; top:0; z-index:1040; box-shadow:var(--shadow); }
        .top-nav .toggle-sidebar { display:none; background:none; border:none; font-size:1.4rem; color:var(--text-dark); cursor:pointer; }
        .top-nav .user-info { display:flex; align-items:center; gap:18px; }
        .top-nav .avatar { width:38px; height:38px; border-radius:50%; background:var(--primary); color:#fff; display:flex; align-items:center; justify-content:center; font-weight:600; }
        .top-nav .theme-toggle { background:none; border:none; font-size:1.2rem; color:var(--text-dark); cursor:pointer; padding:4px 8px; border-radius:6px; }
        .top-nav .logout-btn { background:none; border:none; color:#dc3545; font-weight:500; cursor:pointer; padding:4px 12px; border-radius:6px; text-decoration:none; }
        .page-content { padding:28px; flex:1; }
        .stat-card { background:var(--bg-white); border-radius:14px; padding:22px 24px; box-shadow:var(--shadow); border:1px solid var(--border-color); height:100%; }
        .stat-card .icon { width:50px; height:50px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.5rem; }
        .stat-card .icon.blue { background:#e3f0ff; color:var(--primary); }
        .stat-card .icon.green { background:#e6f9ed; color:#0d9e4b; }
        .stat-card .icon.orange { background:#fff3e0; color:#e67e22; }
        .stat-card .icon.purple { background:#f0e6ff; color:#7c3aed; }
        .stat-card .number { font-size:2rem; font-weight:700; }
        .stat-card .label { color:var(--text-muted); font-size:0.95rem; }
        .table-container { background:var(--bg-white); border-radius:14px; padding:20px 0 0; border:1px solid var(--border-color); box-shadow:var(--shadow); overflow:hidden; }
        .table-container .table-header { padding:0 20px 16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid var(--border-color); }
        .table-container table th { background:var(--bg-light); font-size:0.85rem; text-transform:uppercase; }
        .form-card { background:var(--bg-white); border-radius:14px; padding:28px 30px; border:1px solid var(--border-color); box-shadow:var(--shadow); }
        .form-control, .form-select { border-radius:8px; padding:10px 14px; }
        .status-badge { padding:4px 12px; border-radius:20px; font-size:0.8rem; font-weight:500; }
        .status-badge.present, .status-badge.paid, .status-badge.available { background:#e6f9ed; color:#0d9e4b; }
        .status-badge.absent, .status-badge.unpaid { background:#fde8e8; color:#dc3545; }
        .status-badge.late, .status-badge.pending, .status-badge.borrowed { background:#fff3e0; color:#e67e22; }
        .status-badge.returned { background:#e3f0ff; color:var(--primary); }
        .btn-sm-icon { padding:4px 10px; font-size:0.8rem; }
        @media (max-width:992px) { .sidebar { transform:translateX(-100%); } .sidebar.open { transform:translateX(0); } .main-content { margin-left:0; } .top-nav .toggle-sidebar { display:block; } .page-content { padding:18px; } }
    </style>
</head>
<body>
    <nav class="sidebar" id="sidebar">
        <div class="brand"><i class="fas fa-school"></i><span>ASSMS</span></div>
        <div class="nav-section">Main</div>
        <a class="nav-link active" data-page="dashboard"><i class="fas fa-home"></i> Dashboard</a>
        <a class="nav-link" data-page="students"><i class="fas fa-user-graduate"></i> Students</a>
        <a class="nav-link" data-page="teachers"><i class="fas fa-chalkboard-teacher"></i> Teachers</a>
        <a class="nav-link" data-page="classes"><i class="fas fa-layer-group"></i> Classes</a>
        <div class="nav-section">Operations</div>
        <a class="nav-link" data-page="attendance"><i class="fas fa-calendar-check"></i> Attendance</a>
        <a class="nav-link" data-page="examinations"><i class="fas fa-pencil-alt"></i> Examinations</a>
        <a class="nav-link" data-page="library"><i class="fas fa-book"></i> Library</a>
        <a class="nav-link" data-page="finance"><i class="fas fa-coins"></i> Finance</a>
        <div class="nav-section">System</div>
        <a class="nav-link" data-page="users"><i class="fas fa-users-cog"></i> User Management</a>
        <a class="nav-link" data-page="reports"><i class="fas fa-chart-bar"></i> Reports</a>
        <a class="nav-link" data-page="profile"><i class="fas fa-id-card"></i> Student Profile</a>
    </nav>

    <div class="main-content">
        <header class="top-nav">
            <button class="toggle-sidebar" id="toggleSidebarBtn"><i class="fas fa-bars"></i></button>
            <div></div>
            <div class="user-info">
                <button class="theme-toggle" id="themeToggle"><i class="fas fa-moon"></i></button>
                <span>{{ session.username }}</span>
                <span class="avatar">{{ session.username[0]|upper }}</span>
                <a href="{{ url_for('logout') }}" class="logout-btn"><i class="fas fa-sign-out-alt me-1"></i> Logout</a>
            </div>
        </header>
        <div class="page-content" id="pageContent"></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Theme toggle
        document.getElementById('themeToggle').addEventListener('click', function() {
            const html = document.documentElement;
            if (html.getAttribute('data-theme') === 'dark') {
                html.removeAttribute('data-theme');
                this.innerHTML = '<i class="fas fa-moon"></i>';
                localStorage.setItem('theme', 'light');
            } else {
                html.setAttribute('data-theme', 'dark');
                this.innerHTML = '<i class="fas fa-sun"></i>';
                localStorage.setItem('theme', 'dark');
            }
        });
        if (localStorage.getItem('theme') === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
            document.getElementById('themeToggle').innerHTML = '<i class="fas fa-sun"></i>';
        }

        // Sidebar toggle
        document.getElementById('toggleSidebarBtn').addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('open');
        });

        // ═══ API HELPERS ═══
        async function api(path, method='GET', body=null) {
            const opts = { method, headers: { 'Content-Type': 'application/json' } };
            if (body) opts.body = JSON.stringify(body);
            const res = await fetch(path, opts);
            return res.json();
        }

        // ═══ RENDER FUNCTIONS ═══
        const pageMap = {};

        pageMap.dashboard = async () => {
            const [students, teachers, attendance, fees] = await Promise.all([
                api('/api/students'), api('/api/teachers'), api('/api/attendance'), api('/api/fees')
            ]);
            const today = new Date().toISOString().slice(0,10);
            const present = attendance.filter(a => a.date === today && a.status === 'present').length;
            const absent = attendance.filter(a => a.date === today && a.status === 'absent').length;
            const paid = fees.filter(f => f.status === 'paid').reduce((s,f) => s + f.amount, 0);
            return `
                <div class="row g-4 mb-4">
                    <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="d-flex align-items-center gap-3"><div class="icon blue"><i class="fas fa-user-graduate"></i></div><div><div class="number">${students.length}</div><div class="label">Students</div></div></div></div></div>
                    <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="d-flex align-items-center gap-3"><div class="icon green"><i class="fas fa-chalkboard-teacher"></i></div><div><div class="number">${teachers.length}</div><div class="label">Teachers</div></div></div></div></div>
                    <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="d-flex align-items-center gap-3"><div class="icon orange"><i class="fas fa-calendar-check"></i></div><div><div class="number">${present}</div><div class="label">Present Today</div><div style="font-size:0.8rem;color:var(--text-muted);">Absent: ${absent}</div></div></div></div></div>
                    <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="d-flex align-items-center gap-3"><div class="icon purple"><i class="fas fa-coins"></i></div><div><div class="number">$${paid}</div><div class="label">Fees Collected</div></div></div></div></div>
                </div>
                <div class="row"><div class="col-12"><div class="stat-card"><h5 class="mb-3">Quick Actions</h5>
                    <div class="d-flex gap-2 flex-wrap">
                        <button class="btn btn-primary" onclick="navigate('students')"><i class="fas fa-user-plus me-2"></i>Add Student</button>
                        <button class="btn btn-success" onclick="navigate('attendance')"><i class="fas fa-calendar-plus me-2"></i>Mark Attendance</button>
                        <button class="btn btn-info" onclick="navigate('finance')"><i class="fas fa-coins me-2"></i>Record Fee</button>
                        <button class="btn btn-warning" onclick="navigate('library')"><i class="fas fa-book me-2"></i>Manage Library</button>
                    </div>
                </div></div></div>
            `;
        };

        pageMap.students = async () => {
            const students = await api('/api/students');
            return `
                <div class="row mb-4"><div class="col-12"><div class="form-card">
                    <h5 class="mb-3"><i class="fas fa-user-plus me-2"></i>Register Student</h5>
                    <form id="studentForm">
                        <div class="row g-3">
                            <div class="col-md-2"><input class="form-control" id="firstName" placeholder="First name" required></div>
                            <div class="col-md-2"><input class="form-control" id="lastName" placeholder="Last name" required></div>
                            <div class="col-md-2"><select class="form-select" id="gender"><option>Male</option><option>Female</option></select></div>
                            <div class="col-md-2"><input class="form-control" id="grade" placeholder="Grade" required></div>
                            <div class="col-md-2"><input class="form-control" id="section" placeholder="Section"></div>
                            <div class="col-md-2"><input class="form-control" id="phone" placeholder="Phone"></div>
                            <div class="col-md-3"><input class="form-control" id="parentName" placeholder="Parent"></div>
                            <div class="col-md-3"><input class="form-control" id="dob" type="date"></div>
                            <div class="col-md-3"><input class="form-control" id="address" placeholder="Address"></div>
                            <div class="col-md-3 d-flex align-items-end"><button type="submit" class="btn btn-primary w-100">Save</button></div>
                        </div>
                    </form>
                </div></div></div>
                <div class="row"><div class="col-12"><div class="table-container">
                    <div class="table-header"><h5>Students (${students.length})</h5></div>
                    <table class="table"><thead><tr><th>ID</th><th>Name</th><th>Grade</th><th>Section</th><th>Phone</th><th>Actions</th></tr></thead>
                        <tbody>${students.map(s => `
                            <tr><td>${s.student_id}</td><td>${s.first_name} ${s.last_name}</td><td>${s.grade}</td><td>${s.section||'-'}</td><td>${s.phone||'-'}</td>
                                <td><button class="btn btn-sm btn-outline-danger btn-sm-icon delete-student" data-id="${s.student_id}"><i class="fas fa-trash"></i></button></td></tr>
                        `).join('')}</tbody></table>
                </div></div></div>
            `;
        };

        pageMap.teachers = async () => {
            const teachers = await api('/api/teachers');
            return `
                <div class="row mb-4"><div class="col-12"><div class="form-card">
                    <h5 class="mb-3"><i class="fas fa-user-plus me-2"></i>Add Teacher</h5>
                    <form id="teacherForm">
                        <div class="row g-3">
                            <div class="col-md-3"><input class="form-control" id="teacherName" placeholder="Full name" required></div>
                            <div class="col-md-3"><input class="form-control" id="teacherDept" placeholder="Department" required></div>
                            <div class="col-md-2"><input class="form-control" id="teacherPhone" placeholder="Phone"></div>
                            <div class="col-md-2"><input class="form-control" id="teacherEmail" type="email" placeholder="Email"></div>
                            <div class="col-md-2 d-flex align-items-end"><button type="submit" class="btn btn-primary w-100">Save</button></div>
                        </div>
                    </form>
                </div></div></div>
                <div class="row"><div class="col-12"><div class="table-container">
                    <div class="table-header"><h5>Teachers (${teachers.length})</h5></div>
                    <table class="table"><thead><tr><th>ID</th><th>Name</th><th>Department</th><th>Phone</th><th>Email</th><th>Actions</th></tr></thead>
                        <tbody>${teachers.map(t => `
                            <tr><td>${t.teacher_id}</td><td>${t.name}</td><td>${t.department}</td><td>${t.phone||'-'}</td><td>${t.email||'-'}</td>
                                <td><button class="btn btn-sm btn-outline-danger btn-sm-icon delete-teacher" data-id="${t.teacher_id}"><i class="fas fa-trash"></i></button></td></tr>
                        `).join('')}</tbody></table>
                </div></div></div>
            `;
        };

        pageMap.classes = async () => `
            <div class="row"><div class="col-12"><div class="table-container">
                <div class="table-header"><h5>Class Management</h5></div>
                <table class="table"><thead><tr><th>Grade</th><th>Sections</th><th>Teachers</th><th>Students</th></tr></thead><tbody>
                    <tr><td>Grade 9</td><td>A, B, C</td><td>Mr. Smith, Ms. Lee</td><td>45</td></tr>
                    <tr><td>Grade 10</td><td>A, B</td><td>Dr. White, Mr. Doe</td><td>38</td></tr>
                    <tr><td>Grade 11</td><td>A, B, C</td><td>Ms. Johnson, Mr. Brown</td><td>42</td></tr>
                    <tr><td>Grade 12</td><td>A, B</td><td>Dr. Adams, Mr. Clark</td><td>36</td></tr>
                </tbody></table>
            </div></div></div>
        `;

        pageMap.attendance = async () => {
            const [attendance, students] = await Promise.all([api('/api/attendance'), api('/api/students')]);
            return `
                <div class="row mb-4"><div class="col-12"><div class="form-card">
                    <h5 class="mb-3"><i class="fas fa-calendar-plus me-2"></i>Record Attendance</h5>
                    <form id="attendanceForm">
                        <div class="row g-3">
                            <div class="col-md-3"><select class="form-select" id="attStudentId"><option value="">Select Student</option>${students.map(s => `<option value="${s.student_id}">${s.first_name} ${s.last_name}</option>`).join('')}</select></div>
                            <div class="col-md-3"><input class="form-control" id="attDate" type="date" value="${new Date().toISOString().slice(0,10)}"></div>
                            <div class="col-md-3"><select class="form-select" id="attStatus"><option value="present">Present</option><option value="absent">Absent</option><option value="late">Late</option></select></div>
                            <div class="col-md-3 d-flex align-items-end"><button type="submit" class="btn btn-primary w-100">Record</button></div>
                        </div>
                    </form>
                </div></div></div>
                <div class="row"><div class="col-12"><div class="table-container">
                    <div class="table-header"><h5>Attendance Records (${attendance.length})</h5></div>
                    <table class="table"><thead><tr><th>ID</th><th>Student</th><th>Date</th><th>Status</th></tr></thead>
                        <tbody>${attendance.map(a => `
                            <tr><td>${a.attendance_id}</td><td>${a.student_name}</td><td>${a.date}</td><td><span class="status-badge ${a.status}">${a.status}</span></td></tr>
                        `).join('')}</tbody></table>
                </div></div></div>
            `;
        };

        pageMap.examinations = async () => {
            const [exams, students, subjects] = await Promise.all([api('/api/exams'), api('/api/students'), api('/api/subjects')]);
            return `
                <div class="row mb-4"><div class="col-12"><div class="form-card">
                    <h5 class="mb-3"><i class="fas fa-pencil-alt me-2"></i>Enter Marks</h5>
                    <form id="examForm">
                        <div class="row g-3">
                            <div class="col-md-3"><select class="form-select" id="examStudentId"><option value="">Select Student</option>${students.map(s => `<option value="${s.student_id}">${s.first_name} ${s.last_name}</option>`).join('')}</select></div>
                            <div class="col-md-3"><select class="form-select" id="examSubjectId"><option value="">Select Subject</option>${subjects.map(s => `<option value="${s.subject_id}">${s.subject_name}</option>`).join('')}</select></div>
                            <div class="col-md-2"><input class="form-control" id="examScore" type="number" placeholder="Score"></div>
                            <div class="col-md-2"><input class="form-control" id="examTerm" placeholder="Term"></div>
                            <div class="col-md-2 d-flex align-items-end"><button type="submit" class="btn btn-primary w-100">Save</button></div>
                        </div>
                    </form>
                </div></div></div>
                <div class="row"><div class="col-12"><div class="table-container">
                    <div class="table-header"><h5>Exam Records (${exams.length})</h5></div>
                    <table class="table"><thead><tr><th>ID</th><th>Student</th><th>Subject</th><th>Score</th><th>Term</th></tr></thead>
                        <tbody>${exams.map(e => `
                            <tr><td>${e.exam_id}</td><td>${e.student_name}</td><td>${e.subject_name}</td><td>${e.score}</td><td>${e.term}</td></tr>
                        `).join('')}</tbody></table>
                </div></div></div>
            `;
        };

        pageMap.library = async () => {
            const [books, borrows, students] = await Promise.all([api('/api/library/books'), api('/api/library/borrows'), api('/api/students')]);
            return `
                <div class="row mb-4"><div class="col-12"><div class="form-card">
                    <h5 class="mb-3"><i class="fas fa-book-open me-2"></i>Register Book</h5>
                    <form id="bookForm">
                        <div class="row g-3">
                            <div class="col-md-3"><input class="form-control" id="bookTitle" placeholder="Title" required></div>
                            <div class="col-md-2"><input class="form-control" id="bookAuthor" placeholder="Author"></div>
                            <div class="col-md-2"><input class="form-control" id="bookQty" type="number" placeholder="Qty"></div>
                            <div class="col-md-2"><input class="form-control" id="bookIsbn" placeholder="ISBN"></div>
                            <div class="col-md-3 d-flex align-items-end"><button type="submit" class="btn btn-primary w-100">Add Book</button></div>
                        </div>
                    </form>
                </div></div></div>
                <div class="row"><div class="col-12"><div class="table-container">
                    <div class="table-header"><h5>Books (${books.length})</h5></div>
                    <table class="table"><thead><tr><th>ID</th><th>Title</th><th>Author</th><th>Qty</th><th>Actions</th></tr></thead>
                        <tbody>${books.map(b => `<tr><td>${b.book_id}</td><td>${b.title}</td><td>${b.author||'-'}</td><td>${b.quantity}</td>
                            <td><button class="btn btn-sm btn-outline-danger btn-sm-icon delete-book" data-id="${b.book_id}"><i class="fas fa-trash"></i></button></td></tr>`).join('')}</tbody></table>
                </div></div></div>
                <div class="row mt-4"><div class="col-12"><div class="table-container">
                    <div class="table-header"><h5>Borrow Records</h5></div>
                    <table class="table"><thead><tr><th>ID</th><th>Book</th><th>Student</th><th>Borrowed</th><th>Status</th></tr></thead>
                        <tbody>${borrows.map(b => `<tr><td>${b.borrow_id}</td><td>${b.book_title}</td><td>${b.student_name}</td><td>${b.borrow_date}</td><td><span class="status-badge ${b.status}">${b.status}</span></td></tr>`).join('')}</tbody></table>
                </div></div></div>
            `;
        };

        pageMap.finance = async () => {
            const [fees, students] = await Promise.all([api('/api/fees'), api('/api/students')]);
            const total = fees.reduce((s,f) => s + f.amount, 0);
            const paid = fees.filter(f => f.status === 'paid').reduce((s,f) => s + f.amount, 0);
            return `
                <div class="row g-4 mb-4">
                    <div class="col-md-4"><div class="stat-card"><h6>Total Fees</h6><div class="number">$${total}</div></div></div>
                    <div class="col-md-4"><div class="stat-card"><h6>Collected</h6><div class="number">$${paid}</div></div></div>
                    <div class="col-md-4"><div class="stat-card"><h6>Pending</h6><div class="number">$${total - paid}</div></div></div>
                </div>
                <div class="row mb-4"><div class="col-12"><div class="form-card">
                    <h5 class="mb-3"><i class="fas fa-coins me-2"></i>Record Fee</h5>
                    <form id="feeForm">
                        <div class="row g-3">
                            <div class="col-md-3"><select class="form-select" id="feeStudentId"><option value="">Select Student</option>${students.map(s => `<option value="${s.student_id}">${s.first_name} ${s.last_name}</option>`).join('')}</select></div>
                            <div class="col-md-2"><input class="form-control" id="feeAmount" type="number" placeholder="Amount" required></div>
                            <div class="col-md-2"><select class="form-select" id="feeStatus"><option value="paid">Paid</option><option value="unpaid">Unpaid</option><option value="pending">Pending</option></select></div>
                            <div class="col-md-2"><input class="form-control" id="feeDate" type="date" value="${new Date().toISOString().slice(0,10)}"></div>
                            <div class="col-md-3 d-flex align-items-end"><button type="submit" class="btn btn-primary w-100">Record</button></div>
                        </div>
                    </form>
                </div></div></div>
                <div class="row"><div class="col-12"><div class="table-container">
                    <div class="table-header"><h5>Fee Records (${fees.length})</h5></div>
                    <table class="table"><thead><tr><th>ID</th><th>Student</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
                        <tbody>${fees.map(f => `<tr><td>${f.fee_id}</td><td>${f.student_name}</td><td>$${f.amount}</td><td><span class="status-badge ${f.status}">${f.status}</span></td><td>${f.date}</td></tr>`).join('')}</tbody></table>
                </div></div></div>
            `;
        };

        pageMap.users = async () => {
            const users = await api('/api/users');
            return `
                <div class="row mb-4"><div class="col-12"><div class="form-card">
                    <h5 class="mb-3"><i class="fas fa-user-plus me-2"></i>Create User</h5>
                    <form id="userForm">
                        <div class="row g-3">
                            <div class="col-md-3"><input class="form-control" id="userUsername" placeholder="Username" required></div>
                            <div class="col-md-3"><input class="form-control" id="userPassword" type="password" placeholder="Password" required></div>
                            <div class="col-md-2"><select class="form-select" id="userRole"><option>Admin</option><option>Teacher</option><option>Student</option><option>Parent</option></select></div>
                            <div class="col-md-4 d-flex align-items-end"><button type="submit" class="btn btn-primary w-100">Add User</button></div>
                        </div>
                    </form>
                </div></div></div>
                <div class="row"><div class="col-12"><div class="table-container">
                    <div class="table-header"><h5>Users (${users.length})</h5></div>
                    <table class="table"><thead><tr><th>ID</th><th>Username</th><th>Role</th><th>Actions</th></tr></thead>
                        <tbody>${users.map(u => `<tr><td>${u.id}</td><td>${u.username}</td><td>${u.role}</td>
                            <td><button class="btn btn-sm btn-outline-danger btn-sm-icon delete-user" data-id="${u.id}"><i class="fas fa-trash"></i></button></td></tr>`).join('')}</tbody></table>
                </div></div></div>
            `;
        };

        pageMap.reports = async () => `
            <div class="row g-4">
                <div class="col-md-6"><div class="form-card"><h5>Student Reports</h5><p>Generate student list with GPA.</p><button class="btn btn-primary" onclick="showReport('students')">Generate</button></div></div>
                <div class="col-md-6"><div class="form-card"><h5>Attendance Reports</h5><p>Attendance summary.</p><button class="btn btn-primary" onclick="showReport('attendance')">Generate</button></div></div>
                <div class="col-md-6"><div class="form-card"><h5>Examination Reports</h5><p>Grade and GPA analysis.</p><button class="btn btn-primary" onclick="showReport('exams')">Generate</button></div></div>
                <div class="col-md-6"><div class="form-card"><h5>Financial Reports</h5><p>Fee and payment analysis.</p><button class="btn btn-primary" onclick="showReport('finance')">Generate</button></div></div>
            </div>
            <div id="reportOutput" class="mt-4"></div>
        `;

        pageMap.profile = async () => {
            const students = await api('/api/students');
            return `
                <div class="row mb-4"><div class="col-12"><div class="form-card">
                    <h5><i class="fas fa-id-card me-2"></i>Student Profile</h5>
                    <select class="form-select" id="profileStudentSelect">
                        <option value="">Select Student</option>
                        ${students.map(s => `<option value="${s.student_id}">${s.first_name} ${s.last_name} (ID: ${s.student_id})</option>`).join('')}
                    </select>
                </div></div></div>
                <div id="profileDetails"></div>
            `;
        };

        // ═══ NAVIGATION ═══
        async function navigate(page) {
            const content = document.getElementById('pageContent');
            content.innerHTML = '<div class="text-center py-5"><i class="fas fa-spinner fa-spin fa-2x"></i></div>';
            try {
                content.innerHTML = await pageMap[page]();
                document.querySelectorAll('.sidebar .nav-link').forEach(l => l.classList.remove('active'));
                document.querySelector(`.sidebar .nav-link[data-page="${page}"]`)?.classList.add('active');
                bindEvents(page);
            } catch (e) {
                content.innerHTML = `<div class="alert alert-danger">Error loading page: ${e.message}</div>`;
            }
        }

        // ═══ EVENT BINDINGS ═══
        function bindEvents(page) {
            // Student form
            document.getElementById('studentForm')?.addEventListener('submit', async (e) => {
                e.preventDefault();
                await api('/api/students', 'POST', {
                    first_name: document.getElementById('firstName').value,
                    last_name: document.getElementById('lastName').value,
                    gender: document.getElementById('gender').value,
                    grade: document.getElementById('grade').value,
                    section: document.getElementById('section').value,
                    phone: document.getElementById('phone').value,
                    parent: document.getElementById('parentName').value,
                    dob: document.getElementById('dob').value,
                    address: document.getElementById('address').value
                });
                alert('Student saved!');
                navigate('students');
            });

            // Teacher form
            document.getElementById('teacherForm')?.addEventListener('submit', async (e) => {
                e.preventDefault();
                await api('/api/teachers', 'POST', {
                    name: document.getElementById('teacherName').value,
                    department: document.getElementById('teacherDept').value,
                    phone: document.getElementById('teacherPhone').value,
                    email: document.getElementById('teacherEmail').value
                });
                alert('Teacher saved!');
                navigate('teachers');
            });

            // Attendance form
            document.getElementById('attendanceForm')?.addEventListener('submit', async (e) => {
                e.preventDefault();
                const studentId = document.getElementById('attStudentId').value;
                if (!studentId) return alert('Select a student');
                await api('/api/attendance', 'POST', {
                    student_id: parseInt(studentId),
                    date: document.getElementById('attDate').value,
                    status: document.getElementById('attStatus').value
                });
                alert('Attendance recorded!');
                navigate('attendance');
            });

            // Exam form
            document.getElementById('examForm')?.addEventListener('submit', async (e) => {
                e.preventDefault();
                const studentId = document.getElementById('examStudentId').value;
                const subjectId = document.getElementById('examSubjectId').value;
                if (!studentId || !subjectId) return alert('Fill all fields');
                await api('/api/exams', 'POST', {
                    student_id: parseInt(studentId),
                    subject_id: parseInt(subjectId),
                    score: parseFloat(document.getElementById('examScore').value),
                    term: document.getElementById('examTerm').value || 'Term 1'
                });
                alert('Score saved!');
                navigate('examinations');
            });

            // Book form
            document.getElementById('bookForm')?.addEventListener('submit', async (e) => {
                e.preventDefault();
                await api('/api/library/books', 'POST', {
                    title: document.getElementById('bookTitle').value,
                    author: document.getElementById('bookAuthor').value,
                    quantity: parseInt(document.getElementById('bookQty').value) || 0,
                    isbn: document.getElementById('bookIsbn').value
                });
                alert('Book added!');
                navigate('library');
            });

            // Fee form
            document.getElementById('feeForm')?.addEventListener('submit', async (e) => {
                e.preventDefault();
                const studentId = document.getElementById('feeStudentId').value;
                if (!studentId) return alert('Select a student');
                await api('/api/fees', 'POST', {
                    student_id: parseInt(studentId),
                    amount: parseFloat(document.getElementById('feeAmount').value),
                    status: document.getElementById('feeStatus').value,
                    date: document.getElementById('feeDate').value
                });
                alert('Fee recorded!');
                navigate('finance');
            });

            // User form
            document.getElementById('userForm')?.addEventListener('submit', async (e) => {
                e.preventDefault();
                await api('/api/users', 'POST', {
                    username: document.getElementById('userUsername').value,
                    password: document.getElementById('userPassword').value,
                    role: document.getElementById('userRole').value
                });
                alert('User created!');
                navigate('users');
            });

            // Profile select
            document.getElementById('profileStudentSelect')?.addEventListener('change', async function() {
                if (!this.value) return;
                const data = await api(`/api/students/${this.value}/profile`);
                document.getElementById('profileDetails').innerHTML = `
                    <div class="row g-4">
                        <div class="col-md-4"><div class="stat-card"><h6>Personal Info</h6><hr>
                            <p><strong>Name:</strong> ${data.student.first_name} ${data.student.last_name}</p>
                            <p><strong>ID:</strong> ${data.student.student_id}</p>
                            <p><strong>Gender:</strong> ${data.student.gender||'-'}</p>
                            <p><strong>Grade:</strong> ${data.student.grade}</p>
                            <p><strong>Section:</strong> ${data.student.section||'-'}</p>
                            <p><strong>Phone:</strong> ${data.student.phone||'-'}</p>
                            <p><strong>Parent:</strong> ${data.student.parent||'-'}</p>
                            <p><strong>Address:</strong> ${data.student.address||'-'}</p>
                        </div></div>
                        <div class="col-md-4"><div class="stat-card"><h6>Academic Stats</h6><hr>
                            <p><strong>GPA:</strong> ${data.gpa}</p>
                            <p><strong>Average Score:</strong> ${data.average_score}</p>
                            <p><strong>Exams Taken:</strong> ${data.exams.length}</p>
                            <p><strong>Present:</strong> ${data.attendance.present}</p>
                            <p><strong>Absent:</strong> ${data.attendance.absent}</p>
                            <p><strong>Late:</strong> ${data.attendance.late}</p>
                        </div></div>
                        <div class="col-md-4"><div class="stat-card"><h6>Exam Scores</h6><hr>
                            ${data.exams.map(e => `<p><strong>${e.subject}:</strong> ${e.score} (${e.term})</p>`).join('') || '<p>No exams</p>'}
                        </div></div>
                    </div>
                `;
            });

            // Delete buttons
            document.querySelectorAll('.delete-student').forEach(btn => {
                btn.onclick = async () => {
                    if (!confirm('Delete student?')) return;
                    await api(`/api/students/${btn.dataset.id}`, 'DELETE');
                    navigate('students');
                };
            });
            document.querySelectorAll('.delete-teacher').forEach(btn => {
                btn.onclick = async () => {
                    if (!confirm('Delete teacher?')) return;
                    await api(`/api/teachers/${btn.dataset.id}`, 'DELETE');
                    navigate('teachers');
                };
            });
            document.querySelectorAll('.delete-book').forEach(btn => {
                btn.onclick = async () => {
                    if (!confirm('Delete book?')) return;
                    await api(`/api/library/books/${btn.dataset.id}`, 'DELETE');
                    navigate('library');
                };
            });
            document.querySelectorAll('.delete-user').forEach(btn => {
                btn.onclick = async () => {
                    if (!confirm('Delete user?')) return;
                    await api(`/api/users/${btn.dataset.id}`, 'DELETE');
                    navigate('users');
                };
            });
        }

        // ═══ REPORT SHOW ═══
        async function showReport(type) {
            const data = await api(`/api/reports/${type}`);
            let html = '<div class="form-card"><h5>Report Results</h5><hr><table class="table"><thead><tr>';
            if (data.length > 0) {
                Object.keys(data[0]).forEach(k => html += `<th>${k}</th>`);
                html += '</tr></thead><tbody>';
                data.forEach(row => {
                    html += '<tr>';
                    Object.values(row).forEach(v => html += `<td>${v}</td>`);
                    html += '</tr>';
                });
                html += '</tbody></table></div>';
            } else {
                html += '<th>No data</th></tr></tbody></table></div>';
            }
            document.getElementById('reportOutput').innerHTML = html;
        }

        // Sidebar nav
        document.querySelectorAll('.sidebar .nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                navigate(link.dataset.page);
                if (window.innerWidth <= 992) {
                    document.getElementById('sidebar').classList.remove('open');
                }
            });
        });

        // Expose globals
        window.navigate = navigate;
        window.showReport = showReport;

        // Initial load
        navigate('dashboard');
    </script>
</body>
</html>
"""


# ═════════════════════════════════════════════════════════════════════════════
# DATABASE INITIALIZATION
# ═════════════════════════════════════════════════════════════════════════════

def init_db(app):
    with app.app_context():
        db.create_all()

        # Create default admin user
        if not User.query.filter_by(username='admin').first():
            admin = User(
                username='admin',
                password=hash_password('admin123'),
                role='Admin'
            )
            db.session.add(admin)
            print("✓ Created default admin user (admin / admin123)")

        # Create demo teacher
        if not User.query.filter_by(username='teacher').first():
            teacher = User(
                username='teacher',
                password=hash_password('pass'),
                role='Teacher'
            )
            db.session.add(teacher)

        # Create demo student
        if not User.query.filter_by(username='student').first():
            student = User(
                username='student',
                password=hash_password('pass'),
                role='Student'
            )
            db.session.add(student)

        # Create demo parent
        if not User.query.filter_by(username='parent').first():
            parent = User(
                username='parent',
                password=hash_password('pass'),
                role='Parent'
            )
            db.session.add(parent)

        db.session.commit()

        # Seed subjects
        if Subject.query.count() == 0:
            for name in ['Mathematics', 'Science', 'English', 'History', 'Geography']:
                db.session.add(Subject(subject_name=name))
            db.session.commit()
            print("✓ Seeded subjects")

        # Seed sample students
        if Student.query.count() == 0:
            samples = [
                Student(first_name='Alice', last_name='Johnson', gender='Female', grade='10',
                        section='A', phone='123-456-7890', parent='Mary Johnson', address='123 Main St'),
                Student(first_name='Bob', last_name='Smith', gender='Male', grade='11',
                        section='B', phone='987-654-3210', parent='John Smith', address='456 Oak Ave'),
                Student(first_name='Carol', last_name='Brown', gender='Female', grade='9',
                        section='A', phone='555-1234', parent='Lisa Brown', address='789 Pine St'),
            ]
            for s in samples:
                db.session.add(s)
            db.session.commit()
            print(f"✓ Seeded {len(samples)} sample students")

        # Seed teachers
        if Teacher.query.count() == 0:
            teachers = [
                Teacher(name='Dr. Emily White', department='Mathematics',
                        phone='555-1111', email='emily@school.com'),
                Teacher(name='Mr. John Doe', department='Science',
                        phone='555-2222', email='john@school.com'),
            ]
            for t in teachers:
                db.session.add(t)
            db.session.commit()

        print("\n" + "=" * 60)
        print("  ASSMS Database Initialized Successfully!")
        print("=" * 60)
        print("  Default Login Credentials:")
        print("  ┌─────────────────────────────────────────┐")
        print("  │  Admin:   admin   / admin123            │")
        print("  │  Teacher: teacher / pass                │")
        print("  │  Student: student / pass                │")
        print("  │  Parent:  parent  / pass                │")
        print("  └─────────────────────────────────────────┘")
        print("=" * 60 + "\n")


# ═════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═════════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    app = create_app()
    init_db(app)
    print("🚀 Starting ASSMS server at http://127.0.0.1:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
