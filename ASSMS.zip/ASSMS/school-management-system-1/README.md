# School Management System

This project is a comprehensive web application designed for managing various aspects of a school, including students, teachers, assignments, library resources, examinations, attendance, sections, rooms, tests, and application settings.

## Features

- **Student Management**: Add, update, delete, and view student records.
- **Teacher Management**: Manage teacher information and assignments.
- **Assignment Management**: Create and manage assignments for students.
- **Library Management**: Keep track of books and resources available in the library.
- **Examinations**: Schedule and manage examinations.
- **Attendance Tracking**: Record and manage student attendance with statuses such as present, absent, late, and excused.
- **Sections Management**: Organize students into sections (A, B, C, D, E, F, G, H, J).
- **Room Management**: Manage classroom information.
- **Test Management**: Schedule and manage tests.
- **Dashboard**: Overview of key metrics and information.
- **Settings Management**: Configure application settings.

## Technologies Used

- **Flask**: A lightweight WSGI web application framework.
- **Flask-SQLAlchemy**: An extension for Flask that adds support for SQLAlchemy.
- **PyMySQL**: A pure-Python MySQL client.

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd school-management-system
   ```

2. Create a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. Install the required packages:
   ```
   pip install -r requirements.txt
   ```

4. Set up the database:
   - Configure your database settings in `.env` file.
   - Run migrations:
     ```
     flask db upgrade
     ```

5. Run the application:
   ```
   python run.py
   ```

## Usage

- Access the application in your web browser at `http://127.0.0.1:5000`.
- Use the navigation menu to access different features of the application.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.