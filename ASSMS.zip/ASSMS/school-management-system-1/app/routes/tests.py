from flask import Blueprint, request, jsonify
from app.models.test import Test
from app import db

tests_bp = Blueprint('tests', __name__)

@tests_bp.route('/tests', methods=['GET'])
def get_tests():
    tests = Test.query.all()
    return jsonify([test.to_dict() for test in tests])

@tests_bp.route('/tests', methods=['POST'])
def add_test():
    data = request.get_json()
    new_test = Test(subject=data['subject'], date=data['date'])
    db.session.add(new_test)
    db.session.commit()
    return jsonify(new_test.to_dict()), 201

@tests_bp.route('/tests/<int:test_id>', methods=['PUT'])
def update_test(test_id):
    data = request.get_json()
    test = Test.query.get_or_404(test_id)
    test.subject = data['subject']
    test.date = data['date']
    db.session.commit()
    return jsonify(test.to_dict())

@tests_bp.route('/tests/<int:test_id>', methods=['DELETE'])
def delete_test(test_id):
    test = Test.query.get_or_404(test_id)
    db.session.delete(test)
    db.session.commit()
    return '', 204