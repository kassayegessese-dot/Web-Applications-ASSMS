from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.models.settings import Settings
from app import db

settings_bp = Blueprint('settings', __name__)

@settings_bp.route('/settings', methods=['GET', 'POST'])
def manage_settings():
    if request.method == 'POST':
        # Handle form submission for updating settings
        # Example: update a setting based on form data
        setting_key = request.form.get('key')
        setting_value = request.form.get('value')
        
        setting = Settings.query.filter_by(key=setting_key).first()
        if setting:
            setting.value = setting_value
            db.session.commit()
            flash('Settings updated successfully!', 'success')
        else:
            flash('Setting not found!', 'error')
        
        return redirect(url_for('settings.manage_settings'))
    
    # Fetch all settings to display in the template
    all_settings = Settings.query.all()
    return render_template('settings.html', settings=all_settings)