from flask import Blueprint, request, jsonify
from app.models.room import Room
from app import db

rooms_bp = Blueprint('rooms', __name__)

@rooms_bp.route('/rooms', methods=['GET'])
def get_rooms():
    rooms = Room.query.all()
    return jsonify([room.to_dict() for room in rooms]), 200

@rooms_bp.route('/rooms', methods=['POST'])
def add_room():
    data = request.get_json()
    new_room = Room(room_number=data['room_number'])
    db.session.add(new_room)
    db.session.commit()
    return jsonify(new_room.to_dict()), 201

@rooms_bp.route('/rooms/<int:room_id>', methods=['PUT'])
def update_room(room_id):
    data = request.get_json()
    room = Room.query.get_or_404(room_id)
    room.room_number = data['room_number']
    db.session.commit()
    return jsonify(room.to_dict()), 200

@rooms_bp.route('/rooms/<int:room_id>', methods=['DELETE'])
def delete_room(room_id):
    room = Room.query.get_or_404(room_id)
    db.session.delete(room)
    db.session.commit()
    return jsonify({'message': 'Room deleted successfully'}), 204