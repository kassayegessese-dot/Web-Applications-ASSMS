from flask import Blueprint, request, jsonify
from app.models.assignment import Assignment
from app import db

assignments_bp = Blueprint('assignments', __name__)

@assignments_bp.route('/assignments', methods=['GET'])
def get_assignments():
    assignments = Assignment.query.all()
    return jsonify([assignment.to_dict() for assignment in assignments])

@assignments_bp.route('/assignments', methods=['POST'])
def add_assignment():
    data = request.get_json()
    new_assignment = Assignment(
        title=data['title'],
        description=data['description'],
        due_date=data['due_date']
    )
    db.session.add(new_assignment)
    db.session.commit()
    return jsonify(new_assignment.to_dict()), 201

@assignments_bp.route('/assignments/<int:id>', methods=['PUT'])
def update_assignment(id):
    data = request.get_json()
    assignment = Assignment.query.get_or_404(id)
    assignment.title = data['title']
    assignment.description = data['description']
    assignment.due_date = data['due_date']
    db.session.commit()
    return jsonify(assignment.to_dict())

@assignments_bp.route('/assignments/<int:id>', methods=['DELETE'])
def delete_assignment(id):
    assignment = Assignment.query.get_or_404(id)
    db.session.delete(assignment)
    db.session.commit()
    return jsonify({'message': 'Assignment deleted'}), 204