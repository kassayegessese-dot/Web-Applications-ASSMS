from flask import Blueprint

routes = Blueprint('routes', __name__)

from . import dashboard, students, teachers, assignments, library, examinations, attendance, sections, rooms, tests, settings