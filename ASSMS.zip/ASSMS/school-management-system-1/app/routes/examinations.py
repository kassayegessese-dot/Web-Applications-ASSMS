from flask import Blueprint, request, jsonify
from app.models.exam import Exam
from app import db

examinations_bp = Blueprint('examinations', __name__)

@examinations_bp.route('/examinations', methods=['GET'])
def get_examinations():
    exams = Exam.query.all()
    return jsonify([exam.to_dict() for exam in exams])

@examinations_bp.route('/examinations', methods=['POST'])
def add_examination():
    data = request.get_json()
    new_exam = Exam(subject=data['subject'], date=data['date'])
    db.session.add(new_exam)
    db.session.commit()
    return jsonify(new_exam.to_dict()), 201

@examinations_bp.route('/examinations/<int:exam_id>', methods=['PUT'])
def update_examination(exam_id):
    data = request.get_json()
    exam = Exam.query.get_or_404(exam_id)
    exam.subject = data['subject']
    exam.date = data['date']
    db.session.commit()
    return jsonify(exam.to_dict())

@examinations_bp.route('/examinations/<int:exam_id>', methods=['DELETE'])
def delete_examination(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    db.session.delete(exam)
    db.session.commit()
    return '', 204