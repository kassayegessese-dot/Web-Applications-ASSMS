from flask import Blueprint, request, jsonify
from app.models.library import Library
from app import db

library_bp = Blueprint('library', __name__)

@library_bp.route('/books', methods=['GET'])
def get_books():
    books = Library.query.all()
    return jsonify([book.to_dict() for book in books])

@library_bp.route('/books', methods=['POST'])
def add_book():
    data = request.get_json()
    new_book = Library(book_title=data['book_title'], author=data['author'])
    db.session.add(new_book)
    db.session.commit()
    return jsonify(new_book.to_dict()), 201

@library_bp.route('/books/<int:book_id>', methods=['PUT'])
def update_book(book_id):
    data = request.get_json()
    book = Library.query.get_or_404(book_id)
    book.book_title = data['book_title']
    book.author = data['author']
    db.session.commit()
    return jsonify(book.to_dict())

@library_bp.route('/books/<int:book_id>', methods=['DELETE'])
def delete_book(book_id):
    book = Library.query.get_or_404(book_id)
    db.session.delete(book)
    db.session.commit()
    return '', 204