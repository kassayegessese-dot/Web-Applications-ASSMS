from flask import Blueprint, request, jsonify
from app.models.attendance import Attendance
from app import db

attendance_bp = Blueprint('attendance', __name__)

@attendance_bp.route('/attendance', methods=['GET'])
def get_attendance():
    attendance_records = Attendance.query.all()
    return jsonify([record.to_dict() for record in attendance_records])

@attendance_bp.route('/attendance', methods=['POST'])
def add_attendance():
    data = request.get_json()
    new_record = Attendance(
        student_id=data['student_id'],
        status=data['status']
    )
    db.session.add(new_record)
    db.session.commit()
    return jsonify(new_record.to_dict()), 201

@attendance_bp.route('/attendance/<int:id>', methods=['PUT'])
def update_attendance(id):
    data = request.get_json()
    record = Attendance.query.get_or_404(id)
    record.status = data['status']
    db.session.commit()
    return jsonify(record.to_dict())

@attendance_bp.route('/attendance/<int:id>', methods=['DELETE'])
def delete_attendance(id):
    record = Attendance.query.get_or_404(id)
    db.session.delete(record)
    db.session.commit()
    return '', 204