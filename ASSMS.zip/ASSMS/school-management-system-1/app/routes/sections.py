from flask import Blueprint, request, jsonify
from app.models.section import Section
from app import db

sections_bp = Blueprint('sections', __name__)

@sections_bp.route('/sections', methods=['GET'])
def get_sections():
    sections = Section.query.all()
    return jsonify([section.to_dict() for section in sections]), 200

@sections_bp.route('/sections', methods=['POST'])
def add_section():
    data = request.get_json()
    new_section = Section(name=data['name'])
    db.session.add(new_section)
    db.session.commit()
    return jsonify(new_section.to_dict()), 201

@sections_bp.route('/sections/<int:section_id>', methods=['PUT'])
def update_section(section_id):
    data = request.get_json()
    section = Section.query.get_or_404(section_id)
    section.name = data['name']
    db.session.commit()
    return jsonify(section.to_dict()), 200

@sections_bp.route('/sections/<int:section_id>', methods=['DELETE'])
def delete_section(section_id):
    section = Section.query.get_or_404(section_id)
    db.session.delete(section)
    db.session.commit()
    return jsonify({'message': 'Section deleted successfully'}), 204