from app import db

class Room(db.Model):
    __tablename__ = 'rooms'

    id = db.Column(db.Integer, primary_key=True)
    room_number = db.Column(db.String(10), nullable=False, unique=True)

    def __repr__(self):
        return f'<Room {self.room_number}>'

    def save(self):
        db.session.add(self)
        db.session.commit()

    def delete(self):
        db.session.delete(self)
        db.session.commit()

    @staticmethod
    def get_all_rooms():
        return Room.query.all()

    @staticmethod
    def get_room_by_id(room_id):
        return Room.query.get(room_id)