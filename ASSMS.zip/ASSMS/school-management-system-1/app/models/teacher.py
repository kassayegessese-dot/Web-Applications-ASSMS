from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Teacher(db.Model):
    __tablename__ = 'teachers'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    subject = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<Teacher {self.name}>'

    @classmethod
    def create(cls, name, subject):
        new_teacher = cls(name=name, subject=subject)
        db.session.add(new_teacher)
        db.session.commit()
        return new_teacher

    @classmethod
    def get_all(cls):
        return cls.query.all()

    @classmethod
    def get_by_id(cls, teacher_id):
        return cls.query.get(teacher_id)

    @classmethod
    def update(cls, teacher_id, name=None, subject=None):
        teacher = cls.query.get(teacher_id)
        if teacher:
            if name:
                teacher.name = name
            if subject:
                teacher.subject = subject
            db.session.commit()
        return teacher

    @classmethod
    def delete(cls, teacher_id):
        teacher = cls.query.get(teacher_id)
        if teacher:
            db.session.delete(teacher)
            db.session.commit()
        return teacher