from app import db

class Section(db.Model):
    __tablename__ = 'sections'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(1), nullable=False, unique=True)

    def __repr__(self):
        return f'<Section {self.name}>'

    @classmethod
    def create(cls, name):
        new_section = cls(name=name)
        db.session.add(new_section)
        db.session.commit()
        return new_section

    @classmethod
    def get_all(cls):
        return cls.query.all()

    @classmethod
    def get_by_id(cls, section_id):
        return cls.query.get(section_id)

    @classmethod
    def update(cls, section_id, name):
        section = cls.get_by_id(section_id)
        if section:
            section.name = name
            db.session.commit()
        return section

    @classmethod
    def delete(cls, section_id):
        section = cls.get_by_id(section_id)
        if section:
            db.session.delete(section)
            db.session.commit()
        return section