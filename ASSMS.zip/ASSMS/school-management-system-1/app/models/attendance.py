from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Attendance(db.Model):
    __tablename__ = 'attendance'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    status = db.Column(db.String(10), nullable=False)  # present, absent, late, excused
    date = db.Column(db.Date, nullable=False)

    student = db.relationship('Student', backref='attendance_records')

    def __repr__(self):
        return f'<Attendance {self.id} - Student ID: {self.student_id}, Status: {self.status}, Date: {self.date}>'

    @classmethod
    def create(cls, student_id, status, date):
        attendance_record = cls(student_id=student_id, status=status, date=date)
        db.session.add(attendance_record)
        db.session.commit()
        return attendance_record

    @classmethod
    def get_all(cls):
        return cls.query.all()

    @classmethod
    def update(cls, record_id, status):
        attendance_record = cls.query.get(record_id)
        if attendance_record:
            attendance_record.status = status
            db.session.commit()
        return attendance_record

    @classmethod
    def delete(cls, record_id):
        attendance_record = cls.query.get(record_id)
        if attendance_record:
            db.session.delete(attendance_record)
            db.session.commit()
        return attendance_record