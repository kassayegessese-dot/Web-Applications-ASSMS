from app import db

class Test(db.Model):
    __tablename__ = 'tests'

    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False)

    def __repr__(self):
        return f'<Test {self.subject} on {self.date}>'

    @staticmethod
    def create(subject, date):
        new_test = Test(subject=subject, date=date)
        db.session.add(new_test)
        db.session.commit()
        return new_test

    @staticmethod
    def get_all():
        return Test.query.all()

    @staticmethod
    def get_by_id(test_id):
        return Test.query.get(test_id)

    @staticmethod
    def update(test_id, subject=None, date=None):
        test = Test.query.get(test_id)
        if test:
            if subject:
                test.subject = subject
            if date:
                test.date = date
            db.session.commit()
        return test

    @staticmethod
    def delete(test_id):
        test = Test.query.get(test_id)
        if test:
            db.session.delete(test)
            db.session.commit()
        return test