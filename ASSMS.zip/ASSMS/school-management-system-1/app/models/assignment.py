from datetime import datetime
from app import db

class Assignment(db.Model):
    __tablename__ = 'assignments'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    due_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, title, description, due_date):
        self.title = title
        self.description = description
        self.due_date = due_date

    def __repr__(self):
        return f'<Assignment {self.title}>'

    @staticmethod
    def create_assignment(title, description, due_date):
        new_assignment = Assignment(title, description, due_date)
        db.session.add(new_assignment)
        db.session.commit()
        return new_assignment

    @staticmethod
    def get_all_assignments():
        return Assignment.query.all()

    @staticmethod
    def get_assignment_by_id(assignment_id):
        return Assignment.query.get(assignment_id)

    @staticmethod
    def update_assignment(assignment_id, title, description, due_date):
        assignment = Assignment.query.get(assignment_id)
        if assignment:
            assignment.title = title
            assignment.description = description
            assignment.due_date = due_date
            db.session.commit()
        return assignment

    @staticmethod
    def delete_assignment(assignment_id):
        assignment = Assignment.query.get(assignment_id)
        if assignment:
            db.session.delete(assignment)
            db.session.commit()
        return assignment