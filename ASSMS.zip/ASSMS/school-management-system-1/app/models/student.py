from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Student(db.Model):
    __tablename__ = 'students'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    section = db.Column(db.String(1), nullable=False)  # Sections A, B, C, D, E, F, G, H, J

    def __repr__(self):
        return f'<Student {self.name}>'

    @classmethod
    def create(cls, name, age, section):
        new_student = cls(name=name, age=age, section=section)
        db.session.add(new_student)
        db.session.commit()
        return new_student

    @classmethod
    def get_all(cls):
        return cls.query.all()

    @classmethod
    def get_by_id(cls, student_id):
        return cls.query.get(student_id)

    @classmethod
    def update(cls, student_id, name=None, age=None, section=None):
        student = cls.query.get(student_id)
        if student:
            if name:
                student.name = name
            if age:
                student.age = age
            if section:
                student.section = section
            db.session.commit()
        return student

    @classmethod
    def delete(cls, student_id):
        student = cls.query.get(student_id)
        if student:
            db.session.delete(student)
            db.session.commit()
        return student