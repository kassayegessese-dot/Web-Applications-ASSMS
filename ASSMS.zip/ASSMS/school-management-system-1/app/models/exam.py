from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Exam(db.Model):
    __tablename__ = 'exams'
    
    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False)

    def __repr__(self):
        return f'<Exam {self.subject} on {self.date}>'

    @classmethod
    def create_exam(cls, subject, date):
        new_exam = cls(subject=subject, date=date)
        db.session.add(new_exam)
        db.session.commit()
        return new_exam

    @classmethod
    def get_exam(cls, exam_id):
        return cls.query.get(exam_id)

    @classmethod
    def update_exam(cls, exam_id, subject=None, date=None):
        exam = cls.query.get(exam_id)
        if exam:
            if subject:
                exam.subject = subject
            if date:
                exam.date = date
            db.session.commit()
        return exam

    @classmethod
    def delete_exam(cls, exam_id):
        exam = cls.query.get(exam_id)
        if exam:
            db.session.delete(exam)
            db.session.commit()
        return exam