from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Library(db.Model):
    __tablename__ = 'libraries'

    id = db.Column(db.Integer, primary_key=True)
    book_title = db.Column(db.String(255), nullable=False)
    author = db.Column(db.String(255), nullable=False)

    def __repr__(self):
        return f'<Library {self.book_title} by {self.author}>'

    def save(self):
        db.session.add(self)
        db.session.commit()

    def delete(self):
        db.session.delete(self)
        db.session.commit()

    @staticmethod
    def get_all_books():
        return Library.query.all()

    @staticmethod
    def get_book_by_id(book_id):
        return Library.query.get(book_id)

    @staticmethod
    def update_book(book_id, book_title, author):
        book = Library.query.get(book_id)
        if book:
            book.book_title = book_title
            book.author = author
            db.session.commit()
        return book