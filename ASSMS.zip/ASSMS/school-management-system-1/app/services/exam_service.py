from app import db
from app.models.exam import Exam

class ExamService:
    @staticmethod
    def create_exam(subject, date):
        new_exam = Exam(subject=subject, date=date)
        db.session.add(new_exam)
        db.session.commit()
        return new_exam

    @staticmethod
    def get_exam(exam_id):
        return Exam.query.get(exam_id)

    @staticmethod
    def update_exam(exam_id, subject=None, date=None):
        exam = Exam.query.get(exam_id)
        if exam:
            if subject:
                exam.subject = subject
            if date:
                exam.date = date
            db.session.commit()
        return exam

    @staticmethod
    def delete_exam(exam_id):
        exam = Exam.query.get(exam_id)
        if exam:
            db.session.delete(exam)
            db.session.commit()
            return True
        return False

    @staticmethod
    def get_all_exams():
        return Exam.query.all()