from app import db
from app.models.attendance import Attendance
from app.models.student import Student
from datetime import datetime

class AttendanceService:
    @staticmethod
    def mark_attendance(student_id, status):
        attendance_record = Attendance(student_id=student_id, status=status, date=datetime.utcnow())
        db.session.add(attendance_record)
        db.session.commit()
        return attendance_record

    @staticmethod
    def get_attendance(student_id):
        return Attendance.query.filter_by(student_id=student_id).all()

    @staticmethod
    def update_attendance(attendance_id, status):
        attendance_record = Attendance.query.get(attendance_id)
        if attendance_record:
            attendance_record.status = status
            db.session.commit()
            return attendance_record
        return None

    @staticmethod
    def delete_attendance(attendance_id):
        attendance_record = Attendance.query.get(attendance_id)
        if attendance_record:
            db.session.delete(attendance_record)
            db.session.commit()
            return True
        return False

    @staticmethod
    def get_attendance_summary(section_id):
        return db.session.query(
            Student.name,
            Attendance.status,
            db.func.count(Attendance.id).label('count')
        ).join(Student).filter(Student.section_id == section_id).group_by(Student.name, Attendance.status).all()