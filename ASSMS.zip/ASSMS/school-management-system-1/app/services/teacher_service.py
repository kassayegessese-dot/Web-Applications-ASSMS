from app import db
from app.models.teacher import Teacher

class TeacherService:
    @staticmethod
    def get_all_teachers():
        return Teacher.query.all()

    @staticmethod
    def get_teacher_by_id(teacher_id):
        return Teacher.query.get(teacher_id)

    @staticmethod
    def add_teacher(name, subject):
        new_teacher = Teacher(name=name, subject=subject)
        db.session.add(new_teacher)
        db.session.commit()
        return new_teacher

    @staticmethod
    def update_teacher(teacher_id, name=None, subject=None):
        teacher = Teacher.query.get(teacher_id)
        if teacher:
            if name:
                teacher.name = name
            if subject:
                teacher.subject = subject
            db.session.commit()
        return teacher

    @staticmethod
    def delete_teacher(teacher_id):
        teacher = Teacher.query.get(teacher_id)
        if teacher:
            db.session.delete(teacher)
            db.session.commit()
        return teacher