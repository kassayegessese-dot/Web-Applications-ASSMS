from app import db
from app.models.student import Student

class StudentService:
    @staticmethod
    def add_student(name, age, section):
        new_student = Student(name=name, age=age, section=section)
        db.session.add(new_student)
        db.session.commit()
        return new_student

    @staticmethod
    def get_student(student_id):
        return Student.query.get(student_id)

    @staticmethod
    def update_student(student_id, name=None, age=None, section=None):
        student = Student.query.get(student_id)
        if student:
            if name:
                student.name = name
            if age:
                student.age = age
            if section:
                student.section = section
            db.session.commit()
        return student

    @staticmethod
    def delete_student(student_id):
        student = Student.query.get(student_id)
        if student:
            db.session.delete(student)
            db.session.commit()
            return True
        return False

    @staticmethod
    def list_students():
        return Student.query.all()