from flask import Flask
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    app.config.from_object('app.config.Config')

    db.init_app(app)

    with app.app_context():
        from .routes import dashboard, students, teachers, assignments, library, examinations, attendance, sections, rooms, tests, settings
        app.register_blueprint(dashboard.bp)
        app.register_blueprint(students.bp)
        app.register_blueprint(teachers.bp)
        app.register_blueprint(assignments.bp)
        app.register_blueprint(library.bp)
        app.register_blueprint(examinations.bp)
        app.register_blueprint(attendance.bp)
        app.register_blueprint(sections.bp)
        app.register_blueprint(rooms.bp)
        app.register_blueprint(tests.bp)
        app.register_blueprint(settings.bp)

    return app