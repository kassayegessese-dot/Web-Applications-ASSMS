def format_date(date):
    return date.strftime("%Y-%m-%d")

def calculate_attendance_percentage(present_days, total_days):
    if total_days == 0:
        return 0
    return (present_days / total_days) * 100

def generate_student_id(name, birthdate):
    return f"{name[:3].upper()}{birthdate.strftime('%y%m%d')}"

def validate_email(email):
    import re
    pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return re.match(pattern, email) is not None

def paginate(query, page, per_page):
    return query.paginate(page, per_page, error_out=False)