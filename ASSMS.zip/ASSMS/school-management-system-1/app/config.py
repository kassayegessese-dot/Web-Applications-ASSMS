class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://username:password@localhost/school_management'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'your_secret_key'
    DEBUG = True  # Set to False in production
    # Add any other configuration settings as needed