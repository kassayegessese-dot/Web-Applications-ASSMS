from app import create_app, db
import unittest

class BasicTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.app = create_app('testing')
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.create_all()

    @classmethod
    def tearDownClass(cls):
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_home_page(self):
        with self.app.test_client() as client:
            response = client.get('/')
            self.assertEqual(response.status_code, 200)

    def test_students_page(self):
        with self.app.test_client() as client:
            response = client.get('/students')
            self.assertEqual(response.status_code, 200)

    def test_teachers_page(self):
        with self.app.test_client() as client:
            response = client.get('/teachers')
            self.assertEqual(response.status_code, 200)

    def test_assignments_page(self):
        with self.app.test_client() as client:
            response = client.get('/assignments')
            self.assertEqual(response.status_code, 200)

    def test_library_page(self):
        with self.app.test_client() as client:
            response = client.get('/library')
            self.assertEqual(response.status_code, 200)

    def test_examinations_page(self):
        with self.app.test_client() as client:
            response = client.get('/examinations')
            self.assertEqual(response.status_code, 200)

    def test_attendance_page(self):
        with self.app.test_client() as client:
            response = client.get('/attendance')
            self.assertEqual(response.status_code, 200)

    def test_sections_page(self):
        with self.app.test_client() as client:
            response = client.get('/sections')
            self.assertEqual(response.status_code, 200)

    def test_rooms_page(self):
        with self.app.test_client() as client:
            response = client.get('/rooms')
            self.assertEqual(response.status_code, 200)

    def test_tests_page(self):
        with self.app.test_client() as client:
            response = client.get('/tests')
            self.assertEqual(response.status_code, 200)

    def test_settings_page(self):
        with self.app.test_client() as client:
            response = client.get('/settings')
            self.assertEqual(response.status_code, 200)

if __name__ == '__main__':
    unittest.main()