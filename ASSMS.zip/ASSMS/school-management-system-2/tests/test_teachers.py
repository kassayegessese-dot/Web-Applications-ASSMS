from app import create_app, db
from app.models import Teacher
import pytest

app = create_app()
app.config['TESTING'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'

@pytest.fixture
def client():
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
        yield client

def test_create_teacher(client):
    response = client.post('/teachers', data={
        'name': 'John Doe',
        'subject': 'Mathematics',
        'email': 'john.doe@example.com'
    })
    assert response.status_code == 201
    assert Teacher.query.count() == 1
    assert Teacher.query.first().name == 'John Doe'

def test_get_teachers(client):
    client.post('/teachers', data={
        'name': 'Jane Smith',
        'subject': 'Science',
        'email': 'jane.smith@example.com'
    })
    response = client.get('/teachers')
    assert response.status_code == 200
    assert b'Jane Smith' in response.data

def test_update_teacher(client):
    client.post('/teachers', data={
        'name': 'Mark Twain',
        'subject': 'Literature',
        'email': 'mark.twain@example.com'
    })
    teacher = Teacher.query.first()
    response = client.put(f'/teachers/{teacher.id}', data={
        'name': 'Mark Twain Updated',
        'subject': 'Literature',
        'email': 'mark.twain.updated@example.com'
    })
    assert response.status_code == 200
    assert Teacher.query.first().name == 'Mark Twain Updated'

def test_delete_teacher(client):
    client.post('/teachers', data={
        'name': 'Emily Dickinson',
        'subject': 'Poetry',
        'email': 'emily.dickinson@example.com'
    })
    teacher = Teacher.query.first()
    response = client.delete(f'/teachers/{teacher.id}')
    assert response.status_code == 204
    assert Teacher.query.count() == 0