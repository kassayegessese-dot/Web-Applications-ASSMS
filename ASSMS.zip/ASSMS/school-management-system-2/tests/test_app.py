from app import create_app

app = create_app()

def test_home():
    client = app.test_client()
    response = client.get('/')
    assert response.status_code == 200

def test_students_route():
    client = app.test_client()
    response = client.get('/students')
    assert response.status_code == 200

def test_teachers_route():
    client = app.test_client()
    response = client.get('/teachers')
    assert response.status_code == 200

def test_assignments_route():
    client = app.test_client()
    response = client.get('/assignments')
    assert response.status_code == 200

def test_library_route():
    client = app.test_client()
    response = client.get('/library')
    assert response.status_code == 200

def test_examinations_route():
    client = app.test_client()
    response = client.get('/examinations')
    assert response.status_code == 200

def test_attendance_route():
    client = app.test_client()
    response = client.get('/attendance')
    assert response.status_code == 200

def test_sections_route():
    client = app.test_client()
    response = client.get('/sections')
    assert response.status_code == 200

def test_rooms_route():
    client = app.test_client()
    response = client.get('/rooms')
    assert response.status_code == 200

def test_tests_route():
    client = app.test_client()
    response = client.get('/tests')
    assert response.status_code == 200

def test_settings_route():
    client = app.test_client()
    response = client.get('/settings')
    assert response.status_code == 200