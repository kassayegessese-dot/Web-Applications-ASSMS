from app import create_app, db
from app.models import Attendance
import pytest

app = create_app()
app.config['TESTING'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'

@pytest.fixture
def client():
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
        yield client

def test_mark_attendance(client):
    response = client.post('/attendance/mark', data={
        'student_id': 1,
        'status': 'present',
        'date': '2023-10-01'
    })
    assert response.status_code == 200
    assert Attendance.query.count() == 1

def test_mark_absent(client):
    response = client.post('/attendance/mark', data={
        'student_id': 1,
        'status': 'absent',
        'date': '2023-10-02'
    })
    assert response.status_code == 200
    assert Attendance.query.count() == 2

def test_mark_late(client):
    response = client.post('/attendance/mark', data={
        'student_id': 1,
        'status': 'late',
        'date': '2023-10-03'
    })
    assert response.status_code == 200
    assert Attendance.query.count() == 3

def test_mark_excused(client):
    response = client.post('/attendance/mark', data={
        'student_id': 1,
        'status': 'excused',
        'date': '2023-10-04'
    })
    assert response.status_code == 200
    assert Attendance.query.count() == 4

def test_attendance_calendar(client):
    response = client.get('/attendance/calendar')
    assert response.status_code == 200
    assert b'Attendance Calendar' in response.data