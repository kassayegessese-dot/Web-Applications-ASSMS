from app import create_app, db
from app.models import Student
import pytest

app = create_app()
app.config['TESTING'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'

@pytest.fixture
def client():
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
        yield client

def test_create_student(client):
    response = client.post('/students', data={
        'name': 'John Doe',
        'age': 15,
        'section': 'A'
    })
    assert response.status_code == 201
    student = Student.query.first()
    assert student.name == 'John Doe'
    assert student.age == 15
    assert student.section == 'A'

def test_get_students(client):
    client.post('/students', data={
        'name': 'Jane Doe',
        'age': 16,
        'section': 'B'
    })
    response = client.get('/students')
    assert response.status_code == 200
    assert b'Jane Doe' in response.data

def test_update_student(client):
    client.post('/students', data={
        'name': 'John Doe',
        'age': 15,
        'section': 'A'
    })
    student = Student.query.first()
    response = client.put(f'/students/{student.id}', data={
        'name': 'John Smith',
        'age': 16,
        'section': 'A'
    })
    assert response.status_code == 200
    updated_student = Student.query.get(student.id)
    assert updated_student.name == 'John Smith'

def test_delete_student(client):
    client.post('/students', data={
        'name': 'John Doe',
        'age': 15,
        'section': 'A'
    })
    student = Student.query.first()
    response = client.delete(f'/students/{student.id}')
    assert response.status_code == 204
    assert Student.query.get(student.id) is None