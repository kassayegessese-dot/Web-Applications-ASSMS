from app.extensions import db
from app.models import Room

class RoomService:
    @staticmethod
    def create_room(room_number, capacity):
        new_room = Room(room_number=room_number, capacity=capacity)
        db.session.add(new_room)
        db.session.commit()
        return new_room

    @staticmethod
    def get_all_rooms():
        return Room.query.all()

    @staticmethod
    def get_room_by_id(room_id):
        return Room.query.get(room_id)

    @staticmethod
    def update_room(room_id, room_number=None, capacity=None):
        room = Room.query.get(room_id)
        if room:
            if room_number:
                room.room_number = room_number
            if capacity:
                room.capacity = capacity
            db.session.commit()
        return room

    @staticmethod
    def delete_room(room_id):
        room = Room.query.get(room_id)
        if room:
            db.session.delete(room)
            db.session.commit()
        return room is not None