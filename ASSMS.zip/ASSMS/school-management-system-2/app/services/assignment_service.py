from app.extensions import db
from app.models import Assignment

class AssignmentService:
    @staticmethod
    def create_assignment(title, description, due_date, teacher_id):
        new_assignment = Assignment(title=title, description=description, due_date=due_date, teacher_id=teacher_id)
        db.session.add(new_assignment)
        db.session.commit()
        return new_assignment

    @staticmethod
    def get_all_assignments():
        return Assignment.query.all()

    @staticmethod
    def get_assignment_by_id(assignment_id):
        return Assignment.query.get(assignment_id)

    @staticmethod
    def update_assignment(assignment_id, title, description, due_date, teacher_id):
        assignment = AssignmentService.get_assignment_by_id(assignment_id)
        if assignment:
            assignment.title = title
            assignment.description = description
            assignment.due_date = due_date
            assignment.teacher_id = teacher_id
            db.session.commit()
            return assignment
        return None

    @staticmethod
    def delete_assignment(assignment_id):
        assignment = AssignmentService.get_assignment_by_id(assignment_id)
        if assignment:
            db.session.delete(assignment)
            db.session.commit()
            return True
        return False