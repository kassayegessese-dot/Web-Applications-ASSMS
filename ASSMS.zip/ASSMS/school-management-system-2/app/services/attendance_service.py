from datetime import datetime
from app.extensions import db

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(10), nullable=False)  # present, absent, late, excused
    remarks = db.Column(db.String(255), nullable=True)

    student = db.relationship('Student', back_populates='attendance_records')

class AttendanceService:
    @staticmethod
    def mark_attendance(student_id, date, status, remarks=None):
        attendance_record = Attendance(student_id=student_id, date=date, status=status, remarks=remarks)
        db.session.add(attendance_record)
        db.session.commit()
        return attendance_record

    @staticmethod
    def get_attendance(student_id, start_date, end_date):
        return Attendance.query.filter(
            Attendance.student_id == student_id,
            Attendance.date >= start_date,
            Attendance.date <= end_date
        ).all()

    @staticmethod
    def update_attendance(attendance_id, status, remarks=None):
        attendance_record = Attendance.query.get(attendance_id)
        if attendance_record:
            attendance_record.status = status
            attendance_record.remarks = remarks
            db.session.commit()
        return attendance_record

    @staticmethod
    def delete_attendance(attendance_id):
        attendance_record = Attendance.query.get(attendance_id)
        if attendance_record:
            db.session.delete(attendance_record)
            db.session.commit()
        return attendance_record

    @staticmethod
    def get_attendance_summary(student_id):
        return db.session.query(
            Attendance.status,
            db.func.count(Attendance.id)
        ).filter(Attendance.student_id == student_id).group_by(Attendance.status).all()