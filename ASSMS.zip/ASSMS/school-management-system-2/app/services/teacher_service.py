from app.extensions import db
from app.models import Teacher

class TeacherService:
    @staticmethod
    def add_teacher(data):
        new_teacher = Teacher(**data)
        db.session.add(new_teacher)
        db.session.commit()
        return new_teacher

    @staticmethod
    def get_teacher(teacher_id):
        return Teacher.query.get(teacher_id)

    @staticmethod
    def update_teacher(teacher_id, data):
        teacher = Teacher.query.get(teacher_id)
        if teacher:
            for key, value in data.items():
                setattr(teacher, key, value)
            db.session.commit()
        return teacher

    @staticmethod
    def delete_teacher(teacher_id):
        teacher = Teacher.query.get(teacher_id)
        if teacher:
            db.session.delete(teacher)
            db.session.commit()
            return True
        return False

    @staticmethod
    def list_teachers():
        return Teacher.query.all()