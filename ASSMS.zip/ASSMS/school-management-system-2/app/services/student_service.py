from app.extensions import db
from app.models import Student

class StudentService:
    @staticmethod
    def add_student(data):
        student = Student(**data)
        db.session.add(student)
        db.session.commit()
        return student

    @staticmethod
    def get_student(student_id):
        return Student.query.get(student_id)

    @staticmethod
    def update_student(student_id, data):
        student = Student.query.get(student_id)
        if student:
            for key, value in data.items():
                setattr(student, key, value)
            db.session.commit()
        return student

    @staticmethod
    def delete_student(student_id):
        student = Student.query.get(student_id)
        if student:
            db.session.delete(student)
            db.session.commit()
            return True
        return False

    @staticmethod
    def list_students():
        return Student.query.all()