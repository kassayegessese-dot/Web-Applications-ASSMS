from app.extensions import db
from app.models import Book

class LibraryService:
    @staticmethod
    def add_book(title, author, isbn, published_date):
        new_book = Book(title=title, author=author, isbn=isbn, published_date=published_date)
        db.session.add(new_book)
        db.session.commit()
        return new_book

    @staticmethod
    def get_all_books():
        return Book.query.all()

    @staticmethod
    def get_book_by_id(book_id):
        return Book.query.get(book_id)

    @staticmethod
    def update_book(book_id, title=None, author=None, isbn=None, published_date=None):
        book = Book.query.get(book_id)
        if book:
            if title:
                book.title = title
            if author:
                book.author = author
            if isbn:
                book.isbn = isbn
            if published_date:
                book.published_date = published_date
            db.session.commit()
        return book

    @staticmethod
    def delete_book(book_id):
        book = Book.query.get(book_id)
        if book:
            db.session.delete(book)
            db.session.commit()
        return book