from app.extensions import db

class Examination(db.Model):
    __tablename__ = 'examinations'

    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False)
    time = db.Column(db.Time, nullable=False)
    duration = db.Column(db.Integer, nullable=False)  # duration in minutes
    total_marks = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())

    def __repr__(self):
        return f'<Examination {self.subject} on {self.date}>'


def create_examination(subject, date, time, duration, total_marks):
    new_exam = Examination(subject=subject, date=date, time=time, duration=duration, total_marks=total_marks)
    db.session.add(new_exam)
    db.session.commit()
    return new_exam


def get_examinations():
    return Examination.query.all()


def get_examination_by_id(exam_id):
    return Examination.query.get(exam_id)


def update_examination(exam_id, subject, date, time, duration, total_marks):
    exam = get_examination_by_id(exam_id)
    if exam:
        exam.subject = subject
        exam.date = date
        exam.time = time
        exam.duration = duration
        exam.total_marks = total_marks
        db.session.commit()
    return exam


def delete_examination(exam_id):
    exam = get_examination_by_id(exam_id)
    if exam:
        db.session.delete(exam)
        db.session.commit()
    return exam