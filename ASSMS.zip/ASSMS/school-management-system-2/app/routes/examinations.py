from flask import Blueprint, request, jsonify
from app.services.examination_service import ExaminationService

examinations_bp = Blueprint('examinations', __name__)

@examinations_bp.route('/examinations', methods=['GET'])
def list_examinations():
    examinations = ExaminationService.get_all_examinations()
    return jsonify(examinations)

@examinations_bp.route('/examinations', methods=['POST'])
def create_examination():
    data = request.json
    examination = ExaminationService.create_examination(data)
    return jsonify(examination), 201

@examinations_bp.route('/examinations/<int:examination_id>', methods=['GET'])
def get_examination(examination_id):
    examination = ExaminationService.get_examination_by_id(examination_id)
    return jsonify(examination)

@examinations_bp.route('/examinations/<int:examination_id>', methods=['PUT'])
def update_examination(examination_id):
    data = request.json
    examination = ExaminationService.update_examination(examination_id, data)
    return jsonify(examination)

@examinations_bp.route('/examinations/<int:examination_id>', methods=['DELETE'])
def delete_examination(examination_id):
    ExaminationService.delete_examination(examination_id)
    return jsonify({'message': 'Examination deleted successfully'}), 204