from flask import Blueprint, request, render_template, redirect, url_for, flash
from app.services.library_service import LibraryService

library_bp = Blueprint('library', __name__)
library_service = LibraryService()

@library_bp.route('/library', methods=['GET'])
def list_books():
    books = library_service.get_all_books()
    return render_template('library/list.html', books=books)

@library_bp.route('/library/add', methods=['GET', 'POST'])
def add_book():
    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        isbn = request.form['isbn']
        if library_service.add_book(title, author, isbn):
            flash('Book added successfully!', 'success')
            return redirect(url_for('library.list_books'))
        else:
            flash('Error adding book. Please try again.', 'danger')
    return render_template('library/form.html')

@library_bp.route('/library/edit/<int:book_id>', methods=['GET', 'POST'])
def edit_book(book_id):
    book = library_service.get_book_by_id(book_id)
    if request.method == 'POST':
        book.title = request.form['title']
        book.author = request.form['author']
        book.isbn = request.form['isbn']
        if library_service.update_book(book):
            flash('Book updated successfully!', 'success')
            return redirect(url_for('library.list_books'))
        else:
            flash('Error updating book. Please try again.', 'danger')
    return render_template('library/form.html', book=book)

@library_bp.route('/library/delete/<int:book_id>', methods=['POST'])
def delete_book(book_id):
    if library_service.delete_book(book_id):
        flash('Book deleted successfully!', 'success')
    else:
        flash('Error deleting book. Please try again.', 'danger')
    return redirect(url_for('library.list_books'))