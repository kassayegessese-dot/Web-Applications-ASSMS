from flask import Blueprint, request, jsonify, render_template, redirect, url_for
from app.models import Student
from app.extensions import db

students_bp = Blueprint('students', __name__)

@students_bp.route('/students', methods=['GET'])
def list_students():
    students = Student.query.all()
    return render_template('students/list.html', students=students)

@students_bp.route('/students/add', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        section = request.form['section']
        new_student = Student(name=name, age=age, section=section)
        db.session.add(new_student)
        db.session.commit()
        return redirect(url_for('students.list_students'))
    return render_template('students/form.html')

@students_bp.route('/students/edit/<int:student_id>', methods=['GET', 'POST'])
def edit_student(student_id):
    student = Student.query.get_or_404(student_id)
    if request.method == 'POST':
        student.name = request.form['name']
        student.age = request.form['age']
        student.section = request.form['section']
        db.session.commit()
        return redirect(url_for('students.list_students'))
    return render_template('students/form.html', student=student)

@students_bp.route('/students/delete/<int:student_id>', methods=['POST'])
def delete_student(student_id):
    student = Student.query.get_or_404(student_id)
    db.session.delete(student)
    db.session.commit()
    return redirect(url_for('students.list_students'))