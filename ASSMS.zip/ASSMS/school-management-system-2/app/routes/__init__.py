from flask import Blueprint

# Initialize the routes blueprint
routes_bp = Blueprint('routes', __name__)

# Import all route modules to register their routes
from . import auth, dashboard, students, teachers, assignments, library, examinations, attendance, sections, rooms, tests, settings

# Register the blueprints
routes_bp.register_blueprint(auth.bp)
routes_bp.register_blueprint(dashboard.bp)
routes_bp.register_blueprint(students.bp)
routes_bp.register_blueprint(teachers.bp)
routes_bp.register_blueprint(assignments.bp)
routes_bp.register_blueprint(library.bp)
routes_bp.register_blueprint(examinations.bp)
routes_bp.register_blueprint(attendance.bp)
routes_bp.register_blueprint(sections.bp)
routes_bp.register_blueprint(rooms.bp)
routes_bp.register_blueprint(tests.bp)
routes_bp.register_blueprint(settings.bp)