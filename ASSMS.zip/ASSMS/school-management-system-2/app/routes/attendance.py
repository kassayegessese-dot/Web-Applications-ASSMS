from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.models import Attendance
from app.extensions import db
from datetime import datetime

attendance_bp = Blueprint('attendance', __name__)

@attendance_bp.route('/attendance', methods=['GET', 'POST'])
def record_attendance():
    if request.method == 'POST':
        student_id = request.form.get('student_id')
        status = request.form.get('status')
        date = request.form.get('date', datetime.now().strftime('%Y-%m-%d'))

        attendance_record = Attendance(student_id=student_id, status=status, date=date)
        db.session.add(attendance_record)
        db.session.commit()
        flash('Attendance recorded successfully!', 'success')
        return redirect(url_for('attendance.record_attendance'))

    return render_template('attendance/record.html')

@attendance_bp.route('/attendance/calendar')
def attendance_calendar():
    # Logic to display attendance calendar can be implemented here
    return render_template('attendance/calendar.html')

@attendance_bp.route('/attendance/view')
def view_attendance():
    # Logic to view attendance records can be implemented here
    attendance_records = Attendance.query.all()
    return render_template('attendance/view.html', records=attendance_records)