from flask import Blueprint, request, jsonify
from app.models import Teacher
from app.extensions import db

teachers_bp = Blueprint('teachers', __name__)

@teachers_bp.route('/teachers', methods=['GET'])
def list_teachers():
    teachers = Teacher.query.all()
    return jsonify([teacher.to_dict() for teacher in teachers])

@teachers_bp.route('/teachers', methods=['POST'])
def add_teacher():
    data = request.get_json()
    new_teacher = Teacher(name=data['name'], subject=data['subject'])
    db.session.add(new_teacher)
    db.session.commit()
    return jsonify(new_teacher.to_dict()), 201

@teachers_bp.route('/teachers/<int:teacher_id>', methods=['PUT'])
def edit_teacher(teacher_id):
    data = request.get_json()
    teacher = Teacher.query.get_or_404(teacher_id)
    teacher.name = data['name']
    teacher.subject = data['subject']
    db.session.commit()
    return jsonify(teacher.to_dict())

@teachers_bp.route('/teachers/<int:teacher_id>', methods=['DELETE'])
def delete_teacher(teacher_id):
    teacher = Teacher.query.get_or_404(teacher_id)
    db.session.delete(teacher)
    db.session.commit()
    return '', 204