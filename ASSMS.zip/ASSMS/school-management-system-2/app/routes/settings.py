from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.extensions import db
from app.models import Setting

settings_bp = Blueprint('settings', __name__)

@settings_bp.route('/settings', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Handle form submission for settings
        # Example: update settings in the database
        setting_name = request.form.get('setting_name')
        setting_value = request.form.get('setting_value')
        
        setting = Setting.query.filter_by(name=setting_name).first()
        if setting:
            setting.value = setting_value
        else:
            new_setting = Setting(name=setting_name, value=setting_value)
            db.session.add(new_setting)
        
        db.session.commit()
        flash('Settings updated successfully!', 'success')
        return redirect(url_for('settings.index'))

    settings = Setting.query.all()
    return render_template('settings/index.html', settings=settings)