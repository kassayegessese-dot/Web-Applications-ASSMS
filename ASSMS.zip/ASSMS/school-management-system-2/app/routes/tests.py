from flask import Blueprint, request, jsonify
from app.models import Test
from app.extensions import db

tests_bp = Blueprint('tests', __name__)

@tests_bp.route('/tests', methods=['GET'])
def get_tests():
    tests = Test.query.all()
    return jsonify([test.to_dict() for test in tests])

@tests_bp.route('/tests', methods=['POST'])
def create_test():
    data = request.get_json()
    new_test = Test(name=data['name'], date=data['date'], subject=data['subject'])
    db.session.add(new_test)
    db.session.commit()
    return jsonify(new_test.to_dict()), 201

@tests_bp.route('/tests/<int:test_id>', methods=['GET'])
def get_test(test_id):
    test = Test.query.get_or_404(test_id)
    return jsonify(test.to_dict())

@tests_bp.route('/tests/<int:test_id>', methods=['PUT'])
def update_test(test_id):
    test = Test.query.get_or_404(test_id)
    data = request.get_json()
    test.name = data['name']
    test.date = data['date']
    test.subject = data['subject']
    db.session.commit()
    return jsonify(test.to_dict())

@tests_bp.route('/tests/<int:test_id>', methods=['DELETE'])
def delete_test(test_id):
    test = Test.query.get_or_404(test_id)
    db.session.delete(test)
    db.session.commit()
    return '', 204