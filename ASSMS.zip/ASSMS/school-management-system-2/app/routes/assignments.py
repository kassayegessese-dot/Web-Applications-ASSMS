from flask import Blueprint, request, render_template, redirect, url_for, flash
from app.models import Assignment
from app.extensions import db

assignments_bp = Blueprint('assignments', __name__)

@assignments_bp.route('/assignments', methods=['GET'])
def list_assignments():
    assignments = Assignment.query.all()
    return render_template('assignments/list.html', assignments=assignments)

@assignments_bp.route('/assignments/new', methods=['GET', 'POST'])
def create_assignment():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        new_assignment = Assignment(title=title, description=description)
        db.session.add(new_assignment)
        db.session.commit()
        flash('Assignment created successfully!', 'success')
        return redirect(url_for('assignments.list_assignments'))
    return render_template('assignments/form.html')

@assignments_bp.route('/assignments/<int:assignment_id>/edit', methods=['GET', 'POST'])
def edit_assignment(assignment_id):
    assignment = Assignment.query.get_or_404(assignment_id)
    if request.method == 'POST':
        assignment.title = request.form.get('title')
        assignment.description = request.form.get('description')
        db.session.commit()
        flash('Assignment updated successfully!', 'success')
        return redirect(url_for('assignments.list_assignments'))
    return render_template('assignments/form.html', assignment=assignment)

@assignments_bp.route('/assignments/<int:assignment_id>/delete', methods=['POST'])
def delete_assignment(assignment_id):
    assignment = Assignment.query.get_or_404(assignment_id)
    db.session.delete(assignment)
    db.session.commit()
    flash('Assignment deleted successfully!', 'success')
    return redirect(url_for('assignments.list_assignments'))