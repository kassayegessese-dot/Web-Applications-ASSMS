def is_valid_email(email):
    import re
    email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return re.match(email_regex, email) is not None

def is_valid_student_id(student_id):
    return isinstance(student_id, int) and student_id > 0

def is_valid_teacher_id(teacher_id):
    return isinstance(teacher_id, int) and teacher_id > 0

def is_valid_assignment_title(title):
    return isinstance(title, str) and len(title) > 0

def is_valid_section(section):
    valid_sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J']
    return section in valid_sections

def is_valid_room_number(room_number):
    return isinstance(room_number, str) and len(room_number) > 0

def is_valid_attendance_status(status):
    valid_statuses = ['present', 'absent', 'late', 'excused']
    return status in valid_statuses

def is_valid_date(date_str):
    from datetime import datetime
    try:
        datetime.strptime(date_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False