def format_date(date):
    return date.strftime("%Y-%m-%d")

def calculate_attendance_percentage(present_days, total_days):
    if total_days == 0:
        return 0
    return (present_days / total_days) * 100

def generate_student_id(first_name, last_name, birth_year):
    return f"{first_name[0].upper()}{last_name[:5].lower()}{birth_year}"

def is_valid_email(email):
    import re
    email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return re.match(email_regex, email) is not None

def get_section_name(section_code):
    sections = {
        'A': 'Section A',
        'B': 'Section B',
        'C': 'Section C',
        'D': 'Section D',
        'E': 'Section E',
        'F': 'Section F',
        'G': 'Section G',
        'H': 'Section H',
        'J': 'Section J'
    }
    return sections.get(section_code, 'Unknown Section')