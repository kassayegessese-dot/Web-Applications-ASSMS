# School Management System

This is a comprehensive web application for managing various aspects of a school, including students, teachers, assignments, library resources, examinations, attendance, sections, room management, tests, and application settings.

## Features

- **Student Management**: Add, edit, and list student records.
- **Teacher Management**: Manage teacher records with functionalities to add, edit, and list teachers.
- **Assignments**: Create and manage assignments for students.
- **Library Management**: Manage library resources, including adding and listing books.
- **Examinations**: Schedule and manage examinations, including results.
- **Attendance Tracking**: Record attendance with options for present, absent, late, and excused, along with calendar views.
- **Sections Management**: Manage different sections (A, B, C, D, E, F, G, H, J) within the school.
- **Room Management**: Manage classrooms and their assignments.
- **Tests Management**: Schedule and manage tests.
- **Settings Management**: Configure application settings.

## Technologies Used

- **Flask**: A lightweight WSGI web application framework.
- **Flask-SQLAlchemy**: An extension for Flask that adds support for SQLAlchemy.
- **PyMySQL**: A pure-Python MySQL client library.

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd school-management-system
   ```

2. Create a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Set up the database:
   ```
   flask db init
   flask db migrate
   flask db upgrade
   ```

5. Run the application:
   ```
   python run.py
   ```

## Usage

- Access the application in your web browser at `http://127.0.0.1:5000`.
- Use the navigation menu to access different features of the application.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.